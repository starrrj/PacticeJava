*Due to widespread dependence on these scripts in their current form,
no pull requests for changes can be accepted.*
