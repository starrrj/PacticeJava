set define off
INSERT INTO product_descriptions VALUES(1726-
,'SF'-
,UNISTR(-
'LCD-n\00e4ytt\00f6 11/PM'-
),UNISTR(-
'11 tuuman LCD-passiivin\00e4ytt\00f6. K\00e4yt\00e4nn\00f6ss\00e4 t'||-
'\00e4ysin tasaisen, korkean n\00e4ytt\00f6tarkkuuden n\00e4yt\00f6n k'||-
'uvanlaatu on erinomainen. My\00f6s heijastuksia on v\00e4hennetty.'-
));
INSERT INTO product_descriptions VALUES(2359-
,'SF'-
,UNISTR(-
'LCD-n\00e4ytt\00f6 9/PM'-
),UNISTR(-
'9 tuuman LCD-passiivin\00e4ytt\00f6. Pieni n\00e4ytt\00f6 vie v\00e4h'||-
'emm\00e4n tilaa ty\00f6p\00f6yd\00e4ll\00e4 antaen n\00e4in mahdolli'||-
'suuden sujuvampaan ty\00f6skentelyyn. N\00e4ytt\00f6 on plug and play -'||-
'yhteensopiva ja helppo asentaa.'-
));
INSERT INTO product_descriptions VALUES(3060-
,'SF'-
,UNISTR(-
'17 tuuman n\00e4ytt\00f6 17/HR'-
),UNISTR(-
'17 tuuman korkean n\00e4ytt\00f6tarkkuuden kuvaputkin\00e4ytt\00f6 (n'||-
'\00e4ytt\00f6ala 16 tuumaa). Poikkeuksellisen hyv\00e4 kuvallinen suori'||-
'tuskyky yhdistyy lis\00e4\00e4ntyneeseen n\00e4ytt\00f6alaan. N\00e4y'||-
'tt\00f6 tarjoaa uskomattomaan hintaan loistavat v\00e4rit ja ter\00e4v'||-
'\00e4n kuvan. Laitteen edistyneisiin ominaisuuksiin kuuluu mm. OSD-kuvaru'||-
'utun\00e4ytt\00f6.'-
));
INSERT INTO product_descriptions VALUES(2243-
,'SF'-
,UNISTR(-
'17 tuuman n\00e4ytt\00f6 17/HR/F'-
),UNISTR(-
'17 tuuman korkean n\00e4ytt\00f6tarkkuuden suora kuvaputkin\00e4ytt'||-
'\00f6 (n\00e4ytt\00f6ala 16 tuumaa). Enhanced Elliptical Correction Sys'||-
'tem -tekniikka ja suuritiheyksinen fotonitykki takaavat tarkan kuvan koko '||-
'n\00e4yt\00f6n alalla kulmissa saakka.'-
));
INSERT INTO product_descriptions VALUES(3057-
,'SF'-
,UNISTR(-
'17 tuuman n\00e4ytt\00f6 17/SD'-
),UNISTR(-
'17 tuuman korkean n\00e4ytt\00f6tarkkuuden lyhytkuvaputkin\00e4ytt'||-
'\00f6 (n\00e4ytt\00f6ala 16 tuumaa). Suurenmoinen kuvan selkeys ja tark'||-
'kuus. N\00e4ytt\00f6 tarjoaa ammattitasoisen v\00e4rinlaadun mm. teknis'||-
'en suunnittelun ja graafisen alan tarpeisiin, ja suuri ty\00f6p\00f6yt'||-
'\00e4ala parantaa ty\00f6tehokkuutta.'-
));
INSERT INTO product_descriptions VALUES(3061-
,'SF'-
,UNISTR(-
'19 tuuman n\00e4ytt\00f6 19/SD'-
),UNISTR(-
'19 tuuman korkean n\00e4ytt\00f6tarkkuuden lyhytkuvaputkin\00e4ytt'||-
'\00f6 (n\00e4ytt\00f6ala 18 tuumaa). Suurikontrastinen Black Screen -pi'||-
'nnoite tuottaa erinomaisen kuvakontrastin ja harmaas\00e4vyjen toistoalan'||-
'. Multimedia\00e4\00e4net kajahtavat ilmoille luonnollisina ja kirkkaina'||-
' uusista vahvistimella varustetuista kaiuttimista, bassoa s\00e4\00e4st'||-
'\00e4m\00e4tt\00e4. Lis\00e4ksi n\00e4yt\00f6n asennusta ja asetuste'||-
'n tekemist\00e4 helpottavat v\00e4rikoodatut liit\00e4nt\00e4johdot, p'||-
'lug and play -ominaisuus, ja suoraan ruudulta tapahtuva n\00e4yt\00f6nha'||-
'llinta (OSD). Mahtavat multimediaominaisuudet ja internetin ihmeellisyydet'||-
' ovat vain hetken p\00e4\00e4ss\00e4.'-
));
INSERT INTO product_descriptions VALUES(2245-
,'SF'-
,UNISTR(-
'19 tuuman n\00e4ytt\00f6 19/SD/M'-
),UNISTR(-
'19 tuuman mustavalko-lyhytkuvaputkin\00e4ytt\00f6 (n\00e4ytt\00f6ala 1'||-
'8 tuumaa). Vertaansa vailla oleva kuvanlaatu kompaktissa koossa. Opastavan'||-
' OSD-n\00e4yt\00f6n avulla n\00e4yt\00f6n mittasuhteet, v\00e4rit ja '||-
'kuva-asetukset on helppo ja nopea asettaa. N\00e4ytt\00f6 vain kiinni ti'||-
'etokoneeseen, ja ty\00f6skentely voi alkaa.'-
));
INSERT INTO product_descriptions VALUES(3065-
,'SF'-
,UNISTR(-
'21 tuuman n\00e4ytt\00f6 21/D'-
),UNISTR(-
'21 tuuman kuvaputkin\00e4ytt\00f6 (n\00e4ytt\00f6ala 20 tuumaa). Digit'||-
'aalinen OptiScan-tekniikka tukee n\00e4ytt\00f6tarkkuuksia aina 1600 x 1'||-
'200 pikseliin saakka 75 Hz taajuudella. Mitat (K x L x S): 8,3 x 18,5 x 15'||-
' tuumaa (211 x 470 x 381 mm). Kirkas\00e4\00e4niset Platinum Series -kai'||-
'uttimet, jotka saavat virran n\00e4yt\00f6st\00e4, voidaan tarvittaessa'||-
' irrottaa n\00e4yt\00f6st\00e4. Lis\00e4ksi kaiuttimissa on digitaalin'||-
'en audiosoitinliit\00e4nt\00e4. Digitaalisen audiosoittimen \00e4\00e4'||-
'nt\00e4 voidaan kuunnella kaiuttimista tietokonetta k\00e4ynnist\00e4m'||-
'\00e4tt\00e4.'-
));
INSERT INTO product_descriptions VALUES(3331-
,'SF'-
,UNISTR(-
'21 tuuman n\00e4ytt\00f6 21/HR'-
),UNISTR(-
'21 tuuman korkean n\00e4ytt\00f6tarkkuuden n\00e4ytt\00f6 (n\00e4ytt'||-
'\00f6ala 20 tuumaa). T\00e4m\00e4 n\00e4ytt\00f6 sopii erinomaisesti '||-
'mm. yritys-, julkaisu- ja grafiikkak\00e4ytt\00f6\00f6n. Ty\00f6skente'||-
'lyst\00e4 tulee tehokkaampaa, kun suuri n\00e4ytt\00f6 tarjoaa enemm'||-
'\00e4n tilaa k\00e4ytett\00e4ville sovelluksille.'-
));
INSERT INTO product_descriptions VALUES(2252-
,'SF'-
,UNISTR(-
'21 tuuman n\00e4ytt\00f6 21/HR/M'-
),UNISTR(-
'21 tuuman korkean n\00e4ytt\00f6tarkkuuden mustavalkon\00e4ytt\00f6 (n'||-
'\00e4ytt\00f6ala 20 tuumaa). Laitteen mitat: 35,6 x 29,6 x 33,3 cm (14,6'||-
' kg) Pakkaus: 40,53 x 31,24 x 35.39 cm (16,5 kg). Vaakataajuus 31,5-54 kHz'||-
', pystytaajuus 50-120 Hz. Yleismallin virtal\00e4hde 90-132 V, 50-60 Hz.'-
));
INSERT INTO product_descriptions VALUES(3064-
,'SF'-
,UNISTR(-
'21 tuuman n\00e4ytt\00f6 21/SD'-
),UNISTR(-
'21 tuuman lyhytkuvaputkin\00e4ytt\00f6 (n\00e4ytt\00f6ala 20 tuumaa). '||-
'N\00e4yt\00f6n ominaisuuksiin kuuluvat esimerkiksi 0,25-0,28 mm:n pistek'||-
'oko, suurin n\00e4ytt\00f6tarkkuus 1920 x 1200 pikseli\00e4 76 Hz taaju'||-
'udella, OSD-kuvaruutun\00e4ytt\00f6 ja heijastamaton antistaattinen pinn'||-
'oite.'-
));
INSERT INTO product_descriptions VALUES(3155-
,'SF'-
,UNISTR(-
'N\00e4yt\00f6n saranoitu tuki - HD'-
),UNISTR(-
'Saranoitu n\00e4ytt\00f6tuki raskaaseen k\00e4ytt\00f6\00f6n, n\00e4'||-
'yt\00f6n enimm\00e4ispaino 30 kg.'-
));
INSERT INTO product_descriptions VALUES(3234-
,'SF'-
,UNISTR(-
'N\00e4yt\00f6n saranoitu tuki - STD'-
),UNISTR(-
'Saranoitu vakiomallin n\00e4ytt\00f6tuki, n\00e4yt\00f6n enimm\00e4is'||-
'paino 10 kg.'-
));
INSERT INTO product_descriptions VALUES(3350-
,'SF'-
,UNISTR(-
'Plasman\00e4ytt\00f6 10/LE/VGA'-
),UNISTR(-
'10 tuuman v\00e4h\00e4n energiaa kuluttava plasman\00e4ytt\00f6 VGA-n'||-
'\00e4ytt\00f6tarkkuudella.'-
));
INSERT INTO product_descriptions VALUES(2236-
,'SF'-
,UNISTR(-
'Plasman\00e4ytt\00f6 10/TFT/XGA'-
),UNISTR(-
'10 tuuman litte\00e4 TFT-n\00e4ytt\00f6 kannettaviin tietokoneisiin XGA'||-
'-n\00e4ytt\00f6tarkkuudella.'-
));
INSERT INTO product_descriptions VALUES(3054-
,'SF'-
,UNISTR(-
'Plasman\00e4ytt\00f6 10/XGA'-
),UNISTR(-
'10 tuuman vakiomallin plasman\00e4ytt\00f6 XGA-n\00e4ytt\00f6tarkkuude'||-
'lla. T\00e4m\00e4n k\00e4yt\00e4nn\00f6ss\00e4 t\00e4ysin tasaisen,'||-
' korkean n\00e4ytt\00f6tarkkuuden n\00e4yt\00f6n kuvanlaatu on erinoma'||-
'inen. My\00f6s heijastuksia on v\00e4hennetty.'-
));
INSERT INTO product_descriptions VALUES(1782-
,'SF'-
,UNISTR(-
'Compact 400/DQ'-
),UNISTR(-
'400 merkki\00e4 sekunnissa tulostava huippunopea vedostulostin. Mitat (K '||-
'x L x S): 17,34 x 24,26 x 26,32 tuumaa (440 x 616 x 669 mm). Liit\00e4nt'||-
'\00e4: RS-232-sarjaliit\00e4nt\00e4 (9-nastainen), ei laajennuspaikkoja'||-
'. Paperikoko: A4, US Letter.'-
));
INSERT INTO product_descriptions VALUES(2430-
,'SF'-
,UNISTR(-
'Compact 400/LQ'-
),UNISTR(-
'400 merkki\00e4 sekunnissa tulostava huippunopea kirjelaatutulostin. Mita'||-
't (K x L x S): 12,37 x 27,96 x 23,92 tuumaa (314 x 710 x 608 mm). Liit'||-
'\00e4nt\00e4: RS-232-sarjaliit\00e4nt\00e4 (25-nastainen), 3 laajennus'||-
'paikkaa. Paperikoko: A2, A3, A4.'-
));
INSERT INTO product_descriptions VALUES(1792-
,'SF'-
,UNISTR(-
'Industrial 600/DQ'-
),UNISTR(-
'Leve\00e4 600 merkki\00e4 sekunnissa tulostava huippunopea vedostulostin'||-
', jossa on v\00e4rimahdollisuus. Mitat (K x L x S): 22,31 x 25,73 x 20,12'||-
' tuumaa (567 x 654 x 511 mm). Paperikoko: leve\00e4 malli 3 x 5 - 11 x 17'||-
' tuumaa (7,62 x 12,7 - 27,94 x 43,18 cm) reunoihin saakka.'-
));
INSERT INTO product_descriptions VALUES(1791-
,'SF'-
,UNISTR(-
'Industrial 700/HD'-
),UNISTR(-
'700 merkki\00e4 sekunnissa tulostava pistematriisikirjoitin, jonka j'||-
'\00e4m\00e4k\00e4mpi rakenne ja p\00f6lysuojaus mahdollistavat k\00e4'||-
'yt\00f6n teollisuuden tarpeissa. Liit\00e4nt\00e4: Centronics-rinnakkai'||-
'sliit\00e4nt\00e4, IEEE 1284 -yhteensopiva. Paperikoko: leve\00e4 forma'||-
'atti 3 x 5 - 11 x 17 tuumaa (7,62 x 12,7 - 27,94 x 43,18 cm) reunoihin saa'||-
'kka. Muisti: 4 megatavua. Mitat (K x L x S): 9,3 x 16,5 x 13 tuumaa (236 x'||-
' 419 x 330 mm).'-
));
INSERT INTO product_descriptions VALUES(2302-
,'SF'-
,UNISTR(-
'Mustesuihku B/6'-
),UNISTR(-
'Mustavalko-mustesuihkutulostin, 6 sivua minuutissa, tulostustarkkuus 600x3'||-
'00 dpi. Liit\00e4nt\00e4: Centronics-rinnakkaisliit\00e4nt\00e4, IEEE '||-
'1284 -yhteensopiva. Mitat (K x L x S): 7,3 x 17,5 x 14 tuumaa (185 x 445 x'||-
' 356 mm). Paperikoko: A3, A4, US Legal. Ei laajennuspaikkoja.'-
));
INSERT INTO product_descriptions VALUES(2453-
,'SF'-
,UNISTR(-
'Mustesuihku C/4'-
),UNISTR(-
'Mustesuihkuv\00e4ritulostin kahdella erillisell\00e4 mustekasetilla, mus'||-
'tavalkotulostuksessa 6 sivua minuutissa, v\00e4ritulostuksella 4 sivua, t'||-
'ulostustarkkuus 600x300 dpi. Liit\00e4nt\00e4: Kaksisuuntainen IEEE 1284'||-
' -yhteensopiva rinnakkaisliit\00e4nt\00e4 ja RS-232 -sarjaliit\00e4nt'||-
'\00e4 (9-nastainen) sek\00e4 2 avointa EIO-laajennuspaikkaa. Muisti: 8 m'||-
'egatavua, 96 kilotavun vastaanottopuskuri.'-
));
INSERT INTO product_descriptions VALUES(1797-
,'SF'-
,UNISTR(-
'Mustesuihku C/8/HQ'-
),UNISTR(-
'Mustesuihkuv\00e4ritulostin, 8 sivua minuutissa, korkea tulostustarkkuus '||-
'valokuvalaadulla. Muisti: 16 megatavua. Mitat (K x L x S): 7,3 x 17,5 x 14'||-
' tuumaa (185 x 445 x 356 mm). Paperikoko: A4, US Letter, kirjekuoret. Liit'||-
'\00e4nt\00e4: Centronics-rinnakkaisliit\00e4nt\00e4, IEEE 1284 -yhteen'||-
'sopiva.'-
));
INSERT INTO product_descriptions VALUES(2459-
,'SF'-
,UNISTR(-
'LaserPro 1200/8/BW'-
),UNISTR(-
'Ammattitasoinen mustavalkolasertulostin, 1200 dpi -tulostustarkkuus, 8 siv'||-
'ua sekunnissa. Mitat (K x L x S): 22,37 x 19,86 x 21,92 tuumaa (568 x 504 '||-
'x 557 mm). Ohjelmisto: Laajennettu ohjaintuki SPNIX 4.0 -versiota varten, '||-
'sis\00e4iset MS-DOS-tulostinohjaimet: ZoomSmart-skaalaustekniikka, ilmoit'||-
'ustaulu, lehtinen, peilikuva, vesileima, tulostuksen esikatselu, pika-aset'||-
'ukset, lasertulostinmarginaalien emulointi.'-
));
INSERT INTO product_descriptions VALUES(3127-
,'SF'-
,UNISTR(-
'LaserPro 600/6/BW'-
),UNISTR(-
'Vakiomallin mustavalkolasertulostin, 600 dpi -tulostustarkkuus, 6 sivua se'||-
'kunnissa. Liit\00e4nt\00e4: Centronics-rinnakkaisliit\00e4nt\00e4, IEE'||-
'E 1284 -yhteensopiva. Muisti: 8 megatavua, 96 kilotavun vastaanottopuskuri'||-
'. MS-DOS ToolBox -apuohjelmat SPNIX AutoCAM 17 -yhteensopivalle ohjaimelle'||-
'.'-
));
INSERT INTO product_descriptions VALUES(2254-
,'SF'-
,UNISTR(-
'Kiintolevy 10 Gt /I'-
),UNISTR(-
'10 gigatavun sis\00e4inen kiintolevyasema. N\00e4m\00e4 levyasemat on t'||-
'arkoitettu vaativaan k\00e4ytt\00f6\00f6n, joka edellytt\00e4\00e4 ti'||-
'etojen varmaa k\00e4sittely\00e4 yrityksiss\00e4. Asemat sopivat hyvin '||-
'k\00e4ytett\00e4viksi RAID-sovelluksien kanssa. Yleismalliset lis\00e4v'||-
'arustesarjat on asetettu ja esiasennettu asianmukaisiin telineisiin, jotta'||-
' niiden nopea yhdist\00e4minen yrityksen palvelimeen tai tallennusj\00e4'||-
'rjestelm\00e4\00e4n onnistuisi helposti.'-
));
INSERT INTO product_descriptions VALUES(3353-
,'SF'-
,UNISTR(-
'Kiintolevy 10Gt /R'-
),UNISTR(-
'10 gigatavun irrotettava kiintolevyasema. Supra7-levyasemat tarjoavat viim'||-
'eisint\00e4 tekniikkaa yrityksen tehokkuuden parantamiseen, sill\00e4 ne'||-
' nostavat tiedonsiirtonopeuden jopa 160 megatavuun sekunnissa.'-
));
INSERT INTO product_descriptions VALUES(3069-
,'SF'-
,UNISTR(-
'Kiintolevy 10 Gt /S'-
),UNISTR(-
'10 gigatavun kiintolevyasema Standard Mount -kiinnitykseen. Asema on taaks'||-
'ep\00e4in yhteensopiva Supra5-j\00e4rjestelmien kanssa, ja k\00e4ytt'||-
'\00e4jill\00e4 on mahdollisuus lis\00e4t\00e4 tallennuskapasiteettia o'||-
'ttamalla asema k\00e4ytt\00f6\00f6n tarpeen vaatiessa. Supra-asemat poi'||-
'stavat kiinteiden ohjelmistojen yhteensopimattomuuden aiheuttamat riskit.'-
));
INSERT INTO product_descriptions VALUES(2253-
,'SF'-
,UNISTR(-
'Kiintolevy 10 Gt, kierrosluku 5400 /SE'-
),UNISTR(-
'10 gigatavun ulkoinen kiintolevyasema SCSI-liit\00e4nn\00e4ll\00e4, py'||-
'\00f6rint\00e4nopeus 5400 kierrosta minuutissa. Yleismalliset lis\00e4v'||-
'arustesarjat on asetettu ja esiasennettu asianmukaisiin telineisiin, jotta'||-
' niiden nopea yhdist\00e4minen yrityksen palvelimeen tai tallennusj\00e4'||-
'rjestelm\00e4\00e4n onnistuisi helposti. Supra-asemat poistavat kiinteid'||-
'en ohjelmistojen yhteensopimattomuuden aiheuttamat riskit.'-
));
INSERT INTO product_descriptions VALUES(3354-
,'SF'-
,UNISTR(-
'Kiintolevy 12 Gt /I'-
),UNISTR(-
'12 gigatavun sis\00e4inen kiintolevyasema. Supra-asemat poistavat kiintei'||-
'den ohjelmistojen yhteensopimattomuuden aiheuttamat riskit. Taaksep\00e4i'||-
'n yhteensopiva: Supra2- ja Supra3-j\00e4rjestelmien laitteita voidaan yhd'||-
'istell\00e4 ja k\00e4ytt\00e4\00e4 ristiin, kun halutaan optimoida toi'||-
'minta ja varmistaa tuleva kasvu.'-
));
INSERT INTO product_descriptions VALUES(3072-
,'SF'-
,UNISTR(-
'Kiintolevy 12 Gt /N'-
),UNISTR(-
'12 gigatavun kiintolevyasema Narrow Mount -kiinnitykseen. Supra9-asemat vo'||-
'idaan kiinnitt\00e4\00e4 ja irrottaa sammuttamatta laitteistoa. Valmista'||-
'mamme lennossa liitett\00e4v\00e4t kiintolevyasemat ovat tiukkojen luote'||-
'ttavuus- ja suorituskykystandardien mukaiset.'-
));
INSERT INTO product_descriptions VALUES(3334-
,'SF'-
,UNISTR(-
'Kiintolevy 12 Gt /R'-
),UNISTR(-
'12 gigatavun irrotettava kiintolevyasema. Asema on yhteensopiva yrityksen '||-
'useiden eri laitealustojen kanssa, ja se voidaan helposti ottaa k\00e4ytt'||-
'\00f6\00f6n aina tarvittaessa lis\00e4\00e4 tallennuskapasiteettia. Yl'||-
'eismalliset Supra7-levyasemat edustavat toisen sukupolven lennossa liitett'||-
'\00e4vi\00e4 asemia, joiden yhteensopivuus yrityksen palvelimien ja ulko'||-
'isten tallennusj\00e4rjestelmien asennuspaikkojen kanssa on taattu.'-
));
INSERT INTO product_descriptions VALUES(3071-
,'SF'-
,UNISTR(-
'Kiintolevy 12 Gt /S'-
),UNISTR(-
'12 gigatavun kiintolevyasema Standard Mount -kiinnitykseen. Supra9-asemat '||-
'voidaan kiinnitt\00e4\00e4 ja irrottaa sammuttamatta laitteistoa. Valmis'||-
'tamamme lennossa liitett\00e4v\00e4t kiintolevyasemat ovat tiukkojen luo'||-
'tettavuus- ja suorituskykystandardien mukaiset.'-
));
INSERT INTO product_descriptions VALUES(2255-
,'SF'-
,UNISTR(-
'Kiintolevy 12 Gt, kierrosluku 7200 /SE'-
),UNISTR(-
'12 gigatavun ulkoinen SCSI-kiintolevyasema, py\00f6rint\00e4nopeus 7200 '||-
'kierrosta minuutissa. N\00e4m\00e4 levyasemat on tarkoitettu vaativaan k'||-
'\00e4ytt\00f6\00f6n, joka edellytt\00e4\00e4 tietojen varmaa k\00e4s'||-
'ittely\00e4 yrityksiss\00e4. Asemia voidaan k\00e4ytt\00e4\00e4 RAID-'||-
'sovelluksien kanssa. Yleismalliset lis\00e4varustesarjat on asetettu ja e'||-
'siasennettu asianmukaisiin telineisiin, jotta niiden nopea yhdist\00e4min'||-
'en yrityksen palvelimeen tai tallennusj\00e4rjestelm\00e4\00e4n onnistu'||-
'isi helposti.'-
));
INSERT INTO product_descriptions VALUES(1743-
,'SF'-
,UNISTR(-
'Kiintolevy 18,2 Gt, kierrosluku 10 000 /E'-
),UNISTR(-
'Ulkoinen kiintolevyasema, jonka kapasiteetti on 18,2 Gt ja py\00f6rint'||-
'\00e4nopeus jopa 10 000 kierrosta minuutissa. N\00e4m\00e4 levyasemat o'||-
'n tarkoitettu vaativaan k\00e4ytt\00f6\00f6n, joka edellytt\00e4\00e4'||-
' tietojen varmaa k\00e4sittely\00e4 yrityksiss\00e4. Asemat sopivat hyv'||-
'in k\00e4ytett\00e4viksi RAID-sovelluksien kanssa.'-
));
INSERT INTO product_descriptions VALUES(2382-
,'SF'-
,UNISTR(-
'Kiintolevy 18,2 Gt, kierrosluku 10 000 /I'-
),UNISTR(-
'18,2 gigatavun sis\00e4inen SCSI-kiintolevyasema, py\00f6rint\00e4nopeu'||-
's 10 000 kierrosta minuutissa. Supra7 Universal -levyasemat tarjoavat help'||-
'pok\00e4ytt\00f6isin\00e4 vertaansa vailla olevan suojan asiakkaiden si'||-
'joituksille, mahdollistaen laiteyhteensopivuuden monien eri laitealustojen'||-
' kanssa.'-
));
INSERT INTO product_descriptions VALUES(3399-
,'SF'-
,UNISTR(-
'Kiintolevy 18 Gt /SE'-
),UNISTR(-
'18 gigatavun ulkoinen SCSI-kiintolevyasema. Yleismalliset Supra5-kiintolev'||-
'yasemat voidaan liitt\00e4\00e4 lennossa erilaisiin palvelimiin, RAID-la'||-
'iteyhdistelmiin ja ulkoisiin tallennusv\00e4linetelineisiin.'-
));
INSERT INTO product_descriptions VALUES(3073-
,'SF'-
,UNISTR(-
'Kiintolevy 6 Gt /I'-
),UNISTR(-
'6 gigatavun sis\00e4inen kiintolevyasema. Supra-asemat poistavat kiinteid'||-
'en ohjelmistojen yhteensopimattomuuden aiheuttamat riskit.'-
));
INSERT INTO product_descriptions VALUES(1768-
,'SF'-
,UNISTR(-
'Kiintolevy 8,2 Gt, kierrosluku 5400'-
),UNISTR(-
'Kiintolevyasema, jonka kapasiteetti on 8,2 Gt ja py\00f6rint\00e4nopeus '||-
'jopa 5 400 kierrosta minuutissa. Supra-asemat poistavat kiinteiden ohjelmi'||-
'stojen yhteensopimattomuuden aiheuttamat riskit. RS-232-standardin sarjali'||-
'it\00e4nt\00e4.'-
));
INSERT INTO product_descriptions VALUES(2410-
,'SF'-
,UNISTR(-
'Kiintolevy 8,4 Gt, kierrosluku 5400'-
),UNISTR(-
'8,4 gigatavun kiintolevyasema, py\00f6rint\00e4nopeus 5400 kierrosta min'||-
'uutissa. V\00e4hent\00e4\00e4 omistuskustannuksia: asemia voidaan k'||-
'\00e4ytt\00e4\00e4 yrityksen eri laitealustoissa. Valmistamamme lennoss'||-
'a liitett\00e4v\00e4t kiintolevyasema on tiukkojen luotettavuus- ja suor'||-
'ituskykystandardien mukainen.'-
));
INSERT INTO product_descriptions VALUES(2257-
,'SF'-
,UNISTR(-
'Kiintolevy 8 Gt /I'-
),UNISTR(-
'8 gigatavun sis\00e4inen kiintolevyasema. Supra9-asemat voidaan kiinnitt'||-
'\00e4\00e4 ja irrottaa sammuttamatta laitteistoa. Taaksep\00e4in yhteen'||-
'sopiva: Supra2- ja Supra3-j\00e4rjestelmien laitteita voidaan k\00e4ytt'||-
'\00e4\00e4 ristiin, kun halutaan optimoida toiminta ja varmistaa tuleva '||-
'kasvu.'-
));
INSERT INTO product_descriptions VALUES(3400-
,'SF'-
,UNISTR(-
'Kiintolevy 8 Gt /SE'-
),UNISTR(-
'8 gigatavun ulkoinen SCSI-kiintolevyasema. Supra7-levyasemat tarjoavat vii'||-
'meisint\00e4 tekniikkaa yrityksen tehokkuuden parantamiseen, sille ne nos'||-
'tavat tiedonsiirtonopeuden jopa 255 megatavuun sekunnissa.'-
));
INSERT INTO product_descriptions VALUES(3355-
,'SF'-
,UNISTR(-
'Kiintolevy 8 Gt /SI'-
),UNISTR(-
'8 gigatavun sis\00e4inen SCSI-kiintolevyasema. Asema on yhteensopiva yrit'||-
'yksen useiden eri laitealustojen kanssa, ja se voidaan helposti ottaa k'||-
'\00e4ytt\00f6\00f6n aina tarvittaessa lis\00e4\00e4 tallennuskapasite'||-
'ettia.'-
));
INSERT INTO product_descriptions VALUES(1772-
,'SF'-
,UNISTR(-
'Kiintolevy 9,1 Gt, kierrosluku 10 000'-
),UNISTR(-
'Kiintolevyasema, jonka kapasiteetti on 9,2 Gt ja py\00f6rint\00e4nopeus '||-
'jopa 10 000 kierrosta minuutissa. Levyasemat on tarkoitettu k\00e4ytett'||-
'\00e4viksi yritysymp\00e4rist\00f6iss\00e4, joissa varma tietojen s'||-
'\00e4ilytys ja k\00e4sittely on t\00e4rke\00e4\00e4. Toiminta on help'||-
'poa: asemia voidaan k\00e4ytt\00e4\00e4 mist\00e4 tahansa sovelluksest'||-
'a.'-
));
INSERT INTO product_descriptions VALUES(2414-
,'SF'-
,UNISTR(-
'Kiintolevy 9,1 Gt - 10000 /I'-
),UNISTR(-
'9,1 gigatavun sis\00e4inen SCSI-kiintolevyasema, py\00f6rint\00e4nopeus'||-
' 10 000 kierrosta minuutissa. Saatavilla olevien Supra7-levyasemien levyje'||-
'n py\00f6rint\00e4nopeus on 10 000 kierrosta minuutissa ja tallennuskapa'||-
'siteetit 18 ja 9,1 gigatavua. SCSI- ja RS-232-liit\00e4nn\00e4t.'-
));
INSERT INTO product_descriptions VALUES(2415-
,'SF'-
,UNISTR(-
'Kiintolevy 9,1 Gt - 7200'-
),UNISTR(-
'9,1 gigatavun kiintolevyasema, py\00f6rint\00e4nopeus 7200 kierrosta min'||-
'uutissa. Yleismalliset lis\00e4varustesarjat on asetettu ja esiasennettu '||-
'asianmukaisiin telineisiin, jotta niiden nopea yhdist\00e4minen yrityksen'||-
' palvelimeen tai tallennusj\00e4rjestelm\00e4\00e4n onnistuisi helposti'||-
'.'-
));
INSERT INTO product_descriptions VALUES(2395-
,'SF'-
,UNISTR(-
'32 Mt v\00e4limuisti /M'-
),UNISTR(-
'32 megatavun peilattu v\00e4limuisti (100 MHz SDRAM)'-
));
INSERT INTO product_descriptions VALUES(1755-
,'SF'-
,UNISTR(-
'32 Mt v\00e4limuisti /NM'-
),UNISTR(-
'32 megatavun peilaamaton v\00e4limuisti'-
));
INSERT INTO product_descriptions VALUES(2406-
,'SF'-
,UNISTR(-
'64 Mt v\00e4limuisti /M'-
),UNISTR(-
'64 megatavun peilattu v\00e4limuisti'-
));
INSERT INTO product_descriptions VALUES(2404-
,'SF'-
,UNISTR(-
'64 Mt v\00e4limuisti /NM'-
),UNISTR(-
'64 megatavun peilaamaton v\00e4limuisti FPM-muistipiirit on sovitettu 5 v'||-
'oltin SIMM-kammoille, mutta niit\00e4 saa my\00f6s 3,3 voltin DIMM-muist'||-
'ikampoina.'-
));
INSERT INTO product_descriptions VALUES(1770-
,'SF'-
,UNISTR(-
'8 Mt v\00e4limuisti /NM'-
),UNISTR(-
'8 megatavun peilaamaton v\00e4limuisti (100 MHz SDRAM)'-
));
INSERT INTO product_descriptions VALUES(2412-
,'SF'-
,UNISTR(-
'8 Mt EDO-muisti'-
),UNISTR(-
'8 megatavun 8x32 EDO SIMM-muisti. Extended Data Out -tyypin muisti eroaa F'||-
'PM (Fast Page Mode) -muistista v\00e4h\00e4n, mutta silti merkitt\00e4v'||-
'\00e4sti. FPM-muistista poiketen EDO-muistin l\00e4htev\00e4n datan ohj'||-
'aimet pysyv\00e4t p\00e4\00e4ll\00e4, kun muistinohjaus poistaa sarake'||-
'osoitteen ennen uuden kierroksen aloittamista. Siksi uusi datakierros voi '||-
'alkaa ennen kuin edellinen on p\00e4\00e4ttynyt. EDO-muistia saadaan sek'||-
'\00e4 3,3- ett\00e4 5-voltin SIMM- ja DIMM-kampoina.'-
));
INSERT INTO product_descriptions VALUES(2378-
,'SF'-
,UNISTR(-
'DIMM - 128 Mt'-
),UNISTR(-
'128 megatavun DIMM-muisti. SIMM-muisteja vaihdetaan yleens\00e4 DIMM-muis'||-
'teiksi, koska j\00e4lkimm\00e4iset tukevat 64-bittisten prosessorien lev'||-
'e\00e4mpi\00e4 v\00e4yli\00e4. DIMM-muistit ovat 64- tai 72-bittisi'||-
'\00e4, kun taas SIMM-muistit ovat vain 32- tai 36-bittisi\00e4 (pariteet'||-
'tibitit mukaan lukien).'-
));
INSERT INTO product_descriptions VALUES(3087-
,'SF'-
,UNISTR(-
'DIMM - 16 Mt'-
),UNISTR(-
'16 megatavun Citrus OLX DIMM.'-
));
INSERT INTO product_descriptions VALUES(2384-
,'SF'-
,UNISTR(-
'DIMM - 1Gt'-
),UNISTR(-
'DIMM-muisti: 1 gigatavun RAM.'-
));
INSERT INTO product_descriptions VALUES(1749-
,'SF'-
,UNISTR(-
'DIMM - 256 Mt'-
),UNISTR(-
'DIMM-muisti: RAM 256 Mt. (100 MHz Registered SDRAM)'-
));
INSERT INTO product_descriptions VALUES(1750-
,'SF'-
,UNISTR(-
'DIMM - 2 Gt'-
),UNISTR(-
'DIMM-muisti: 2 gigatavun RAM.'-
));
INSERT INTO product_descriptions VALUES(2394-
,'SF'-
,UNISTR(-
'DIMM - 32 Mt'-
),UNISTR(-
'32 megatavun DIMM-muistip\00e4ivitys.'-
));
INSERT INTO product_descriptions VALUES(2400-
,'SF'-
,UNISTR(-
'DIMM - 512 Mt'-
),UNISTR(-
'512 megatavun DIMM-muisti. Muistip\00e4ivitys v\00e4hemmill\00e4 kompon'||-
'enteilla: DIMM-muistikampoja tarvitaan v\00e4hemm\00e4n j\00e4rjestelm'||-
'\00e4n muistinlis\00e4ykseen kuin jos k\00e4ytett\00e4isiin SIMM-muist'||-
'ia. Muistinlaajennuksen enimm\00e4ism\00e4\00e4r\00e4 on kasvanut: Sam'||-
'oilla muistipaikoilla voidaan DIMM-muistia k\00e4ytt\00e4m\00e4ll\00e4'||-
' saada suurempi muistinlaajennus kuin SIMM-muisteilla. DIMM-kampojen molem'||-
'milla puolilla on omat kontaktinsa, jolloin niihin voidaan tallentaa kaksi'||-
' kertaa enemm\00e4n tietoa kuin SIMM-kampoihin.'-
));
INSERT INTO product_descriptions VALUES(1763-
,'SF'-
,UNISTR(-
'DIMM - 64 Mt'-
),UNISTR(-
'DIMM-muisti: 64 Mt RAM (100 MHz Unregistered ECC SDRAM)'-
));
INSERT INTO product_descriptions VALUES(2396-
,'SF'-
,UNISTR(-
'EDO - 32 Mt'-
),UNISTR(-
'EDO-SIMM-muisti: 32 Mt RAM (100 MHz Unregistered ECC SDRAM). FPM-muistin t'||-
'apaan EDO-muistia on saatavissa 3,3- ja 5-volttisina SIMM- ja DIMM-kampoin'||-
'a. Jos EDO-muistia asennetaan tietokoneeseen, joka ei sit\00e4 tue, muist'||-
'i ei ehk\00e4 toimi.'-
));
INSERT INTO product_descriptions VALUES(2272-
,'SF'-
,UNISTR(-
'RAM -16 Mt'-
),UNISTR(-
'SIMM-muisti: 16 megatavun RAM.'-
));
INSERT INTO product_descriptions VALUES(2274-
,'SF'-
,UNISTR(-
'RAM - 32 Mt'-
),UNISTR(-
'SIMM-muisti: 32 megatavun RAM.'-
));
INSERT INTO product_descriptions VALUES(3090-
,'SF'-
,UNISTR(-
'RAM - 48 Mt'-
),UNISTR(-
'48 megatavun SIMM RAM.'-
));
INSERT INTO product_descriptions VALUES(1739-
,'SF'-
,UNISTR(-
'SDRAM - 128 Mt'-
),UNISTR(-
'128 megatavun SDRAM. SDRAM voi k\00e4sitell\00e4 tietoa jopa 100 megaher'||-
'tsin nopeudella, mik\00e4 on jopa nelj\00e4 kertaa tavallista DRAM-muist'||-
'ia nopeammin. SDRAM-muistin t\00e4ysi hy\00f6ty saavutetaan kuitenkin va'||-
'in tietokoneissa, jotka on suunniteltu k\00e4ytt\00e4m\00e4\00e4n kyse'||-
'ist\00e4 muistia. SDRAM-muistia on saatavana 3,3 ja 5 voltin DIMM-kampoin'||-
'a.'-
));
INSERT INTO product_descriptions VALUES(3359-
,'SF'-
,UNISTR(-
'SDRAM - 16 Mt'-
),UNISTR(-
'SDRAM-muistip\00e4ivitysmoduuli, 16 Mt. SDRAM eli Synchronous Dynamic Ran'||-
'dom Access Memory tuli markkinoille EDO-muistin j\00e4lkeen. SDRAM-muisti'||-
'n arkkitehtuuri ja toiminta perustuu perinteiselle DRAM-tekniikalle, mutta'||-
' poikkeaa merkitt\00e4v\00e4sti p\00e4\00e4muistin k\00e4sittelyss'||-
'\00e4, mik\00e4 v\00e4hent\00e4\00e4 tiedonhakuaikoja entisest\00e4'||-
'\00e4n. SDRAM on synkronoitu tietokoneen p\00e4\00e4prosessoria ohjaava'||-
'n kellon kanssa. T\00e4m\00e4 tarkoittaa, ett\00e4 mikroprosessoria ohj'||-
'aava j\00e4rjestelm\00e4n kello ohjaa my\00f6s SDRAM:in toimintaa. N'||-
'\00e4in muistinohjain tiet\00e4\00e4, mill\00e4 kellosyklill\00e4 tie'||-
'topyynt\00f6 on valmiina, jolloin ajoitusviivet poistuvat.'-
));
INSERT INTO product_descriptions VALUES(3088-
,'SF'-
,UNISTR(-
'SDRAM - 32 Mt'-
),UNISTR(-
'32 megatavun SDRAM, jossa on ECC-virheenkorjaus. SDRAM-muistissa on useita'||-
' muistipankkeja, jotka voivat toimia samanaikaisesti. Jatkuva tietovirta s'||-
'aavutetaan vaihtelemalla pankkien v\00e4lill\00e4.'-
));
INSERT INTO product_descriptions VALUES(2276-
,'SF'-
,UNISTR(-
'SDRAM - 48 Mt'-
),UNISTR(-
'SIMM-muisti: RAM - 48 Mt. SDRAM-muisti voi toimia pursketilassa. Pursketil'||-
'assa yht\00e4 dataosoitetta haettaessa kokonainen datalohko haetaan yhden'||-
' asemesta. Oletetaan siis, ett\00e4 seuraava tarvittava tiedonp\00e4tk'||-
'\00e4 on heti edellisen j\00e4lkeen. Koska yleens\00e4 n\00e4in on, ov'||-
'at tiedot heti k\00e4ytett\00e4viss\00e4.'-
));
INSERT INTO product_descriptions VALUES(3086-
,'SF'-
,UNISTR(-
'VRAM - 16 Mt'-
),UNISTR(-
'16 megatavun Citrus Video-RAM. VRAM-muisti on tarkoitettu tietokoneen k'||-
'\00e4sittelem\00e4n kuvatiedon tallentamiseen, eik\00e4 sit\00e4 k'||-
'\00e4ytet\00e4 muuhun. Muisti kehiteltiin mahdollistamaan jatkuva sarjam'||-
'uotoisen tiedon kulku videon\00e4ytt\00f6jen virkistysprosessia varten ('||-
'kuvan piirtoa uudestaan n\00e4yt\00f6lle).'-
));
INSERT INTO product_descriptions VALUES(3091-
,'SF'-
,UNISTR(-
'VRAM - 64 Mt'-
),UNISTR(-
'64 megatavun Citrus Video-RAM. VRAM on kuten DRAM-muisti, mutta videomuist'||-
'ipiiriin on lis\00e4tty ominaisuus nimelt\00e4 siirtorekisteri. VRAM-mui'||-
'stin erityisominaisuutena on, ett\00e4 se voi siirt\00e4\00e4 koko data'||-
'rivin (aina 256 bitti\00e4) siirtorekisteriin yhden kellosyklin aikana. T'||-
'iedonhakuajat v\00e4henev\00e4t huomattavasti, koska mahdollisten hakuke'||-
'rtojen lukum\00e4\00e4r\00e4 v\00e4henee 256 kerrasta vain yhteen. Sii'||-
'rtorekisterin p\00e4\00e4asiallisin etu on, ett\00e4 tietojen siirto re'||-
'kisteriin vapauttaa suorittimen virkist\00e4m\00e4\00e4n n\00e4yt'||-
'\00f6n sen sijaan, ett\00e4 sit\00e4 tarvittaisiin tiedonhakuun. N'||-
'\00e4in datakaistan leveys voidaan kaksinkertaistaa. T\00e4st\00e4 syys'||-
't\00e4 VRAM-muistista puhuttaessa puhutaan kaksiporttisesta muistista. Si'||-
'irtorekisteri\00e4 voidaan kuitenkin k\00e4ytt\00e4\00e4 vain, jos VRA'||-
'M-piirille annetaan asianmukainen komento. Siirtorekisterin k\00e4ytt'||-
'\00f6komento on ohjelmoitu suoraan grafiikkaohjaimeen.'-
));
INSERT INTO product_descriptions VALUES(1787-
,'SF'-
,UNISTR(-
'Prosessori D300'-
),UNISTR(-
'300 Mhz tuplaprosessori. Ainoastaan kevyeen henkil\00f6kohtaiseen k\00e4'||-
'ytt\00f6\00f6n tai tiedostopalvelimeen, jota k\00e4ytt\00e4\00e4 enin'||-
't\00e4\00e4n 5 jatkuvaa k\00e4ytt\00e4j\00e4\00e4. T\00e4m\00e4 tu'||-
'ote poistuu todenn\00e4k\00f6isesti pian markkinoilta.'-
));
INSERT INTO product_descriptions VALUES(2439-
,'SF'-
,UNISTR(-
'Prosessori D400'-
),UNISTR(-
'400 Mhz tuplaprosessori. Hyv\00e4 hinnan ja suorituskyvyn suhde, keskikok'||-
'oisiin LAN-tiedostopalvelimiin (enint. 100 jatkuvaa k\00e4ytt\00e4j'||-
'\00e4\00e4).'-
));
INSERT INTO product_descriptions VALUES(1788-
,'SF'-
,UNISTR(-
'Prosessori D600'-
),UNISTR(-
'600 Mhz tuplaprosessori. Huippuluokan nopea prosessori raskaaseen WAN-palv'||-
'elink\00e4ytt\00f6\00f6n (jopa 200 jatkuvaa k\00e4ytt\00e4j\00e4'||-
'\00e4).'-
));
INSERT INTO product_descriptions VALUES(2375-
,'SF'-
,UNISTR(-
'Grafiikkaprosessori 1024x768'-
),UNISTR(-
'Grafiikkaprosessori 1024 x 768 n\00e4ytt\00f6tarkkuudella. Erinomainen h'||-
'inta/laatu-suhde 2D- ja 3D-sovelluksille SPINX 3.3- ja 4.0 -j\00e4rjestel'||-
'miss\00e4. Yhteen korttin voidaan liitt\00e4\00e4 kaksi n\00e4ytt'||-
'\00f6\00e4, jolloin katselumahdollisuudet tuplaantuvat. Kahdella 17 tuum'||-
'an n\00e4yt\00f6ll\00e4 p\00e4\00e4st\00e4\00e4n suurempaan kuva-al'||-
'aan kuin yhdell\00e4 21 tuuman n\00e4yt\00f6ll\00e4. Erinomainen vaiht'||-
'oehto k\00e4ytt\00e4jille, jotka k\00e4ytt\00e4v\00e4t monta sovellus'||-
'ta samanaikaisesti tai hakevat tietoa usein monista l\00e4hteist\00e4.'-
));
INSERT INTO product_descriptions VALUES(2411-
,'SF'-
,UNISTR(-
'Grafiikkaprosessori 1280 x 1024'-
),UNISTR(-
'Grafiikkaprosessori 1280 x 1024 n\00e4ytt\00f6tarkkuudella. Korkean taso'||-
'n 3D-suorituskyky\00e4 keskitason hintaan: 15 miljoonaa Gouraud-varjostet'||-
'tua kolmiota sekunnissa, optimoidut 3D-ohjaimet MCAD- ja DCC-sovelluksia v'||-
'arten ja lis\00e4ksi k\00e4ytt\00e4j\00e4n muokattavat asetukset. 64 m'||-
'egatavun DDR SDRAM muisti, jossa on yhdistetty kehyspuskuri, joka tukee tr'||-
'ue color -tilaa (16,7 miljoonaa v\00e4ri\00e4) kaikilla vakion\00e4ytt'||-
'\00f6tarkkuuksilla.'-
));
INSERT INTO product_descriptions VALUES(1769-
,'SF'-
,UNISTR(-
'Grafiikkaprosessori 800 x 600'-
),UNISTR(-
'Grafiikkaprosessori 800 x 600 n\00e4ytt\00f6tarkkuudella. Erinomainen ra'||-
'tkaisu mahtavia 2D-ominaisuuksia tai edistyneit\00e4 sovelluksia varten p'||-
'erus-3D-tukea etsiville. Suorituskyvylt\00e4\00e4n erinomainen laite hyv'||-
'in vaativaan k\00e4ytt\00f6\00f6n; antaa k\00e4ytt\00e4j\00e4n keski'||-
'tty\00e4 monimutkaisten mallien renderoinnin sijaan varsinaiseen suunnitt'||-
'eluun.'-
));
INSERT INTO product_descriptions VALUES(2049-
,'SF'-
,UNISTR(-
'Emolevy S300'-
),UNISTR(-
'300-sarjan PC-emolevy.'-
));
INSERT INTO product_descriptions VALUES(2751-
,'SF'-
,UNISTR(-
'Emolevy S450'-
),UNISTR(-
'450-sarjan PC-emolevy.'-
));
INSERT INTO product_descriptions VALUES(3112-
,'SF'-
,UNISTR(-
'Emolevy S500'-
),UNISTR(-
'500-sarjan PC-emolevy.'-
));
INSERT INTO product_descriptions VALUES(2752-
,'SF'-
,UNISTR(-
'Emolevy S550'-
),UNISTR(-
'550-sarjan PC-emolevy.'-
));
INSERT INTO product_descriptions VALUES(2293-
,'SF'-
,UNISTR(-
'Emolevy S600'-
),UNISTR(-
'600-sarjan emolevy.'-
));
INSERT INTO product_descriptions VALUES(3114-
,'SF'-
,UNISTR(-
'Emolevy S900/650+'-
),UNISTR(-
'900-sarjan PC-emolevy, vakioemolevy kaikille 650-sarjan malleille ja yl'||-
'\00f6sp\00e4in.'-
));
INSERT INTO product_descriptions VALUES(3129-
,'SF'-
,UNISTR(-
'\00c4\00e4nikortti STD'-
),UNISTR(-
'Vakio\00e4\00e4nikortti MIDI-liit\00e4nn\00e4ll\00e4, linjatulolla/-l'||-
'\00e4hd\00f6ll\00e4 ja matalaimpendanssi-mikrofoniliit\00e4nn\00e4ll'||-
'\00e4.'-
));
INSERT INTO product_descriptions VALUES(3133-
,'SF'-
,UNISTR(-
'Videokortti /32'-
),UNISTR(-
'Videokortti 32 megatavun v\00e4limuistilla.'-
));
INSERT INTO product_descriptions VALUES(2308-
,'SF'-
,UNISTR(-
'Videokortti /E32'-
),UNISTR(-
'32 megatavun 3-D ELSA-videokortti.'-
));
INSERT INTO product_descriptions VALUES(2496-
,'SF'-
,UNISTR(-
'WSP-prosessori DA-130'-
),UNISTR(-
'Leve\00e4 tallennusprosessori DA-130 alatallennusyksik\00f6ille.'-
));
INSERT INTO product_descriptions VALUES(2497-
,'SF'-
,UNISTR(-
'WSP-prosessori DA-290'-
),UNISTR(-
'Leve\00e4 tallennusprosessori DA-290.'-
));
INSERT INTO product_descriptions VALUES(3106-
,'SF'-
,UNISTR(-
'N\00e4pp\00e4imist\00f6 101/EN'-
),UNISTR(-
'PC/AT-standardin laajennettu n\00e4pp\00e4imist\00f6 (101/102-n\00e4pp'||-
'\00e4iminen). N\00e4pp\00e4imist\00f6n kieli: englanti (amerikanenglan'||-
'ti).'-
));
INSERT INTO product_descriptions VALUES(2289-
,'SF'-
,UNISTR(-
'N\00e4pp\00e4imist\00f6 101/ES'-
),UNISTR(-
'PC/AT-standardin laajennettu n\00e4pp\00e4imist\00f6 (101/102-n\00e4pp'||-
'\00e4iminen). N\00e4pp\00e4imist\00f6n kieli: espanja.'-
));
INSERT INTO product_descriptions VALUES(3110-
,'SF'-
,UNISTR(-
'N\00e4pp\00e4imist\00f6 101/FR'-
),UNISTR(-
'PC/AT-standardin laajennettu n\00e4pp\00e4imist\00f6 (101/102-n\00e4pp'||-
'\00e4iminen). N\00e4pp\00e4imist\00f6n kieli: ranska.'-
));
INSERT INTO product_descriptions VALUES(3108-
,'SF'-
,UNISTR(-
'N\00e4pp\00e4imist\00f6 E/EN'-
),UNISTR(-
'Ergonominen n\00e4pp\00e4imist\00f6, jossa on kaksi erillist\00e4 n'||-
'\00e4pp\00e4inlohkoa ja irrotettava numero-osa. N\00e4pp\00e4imist'||-
'\00f6n asettelu: englanti (amerikanenglanti).'-
));
INSERT INTO product_descriptions VALUES(2058-
,'SF'-
,UNISTR(-
'Hiirialusta + rannetuki'-
),UNISTR(-
'Hiirialustan ja rannetuen yhdistelm\00e4 parantamaan kirjoitusmukavuutta '||-
'ja helpottamaan hiiren k\00e4sittely\00e4.'-
));
INSERT INTO product_descriptions VALUES(2761-
,'SF'-
,UNISTR(-
'Hiirialusta + rannetuki yrityksen logolla'-
),UNISTR(-
'Yrityksen logolla varustettu paketti, jossa on hiirialusta ja rannetuki.'-
));
INSERT INTO product_descriptions VALUES(3117-
,'SF'-
,UNISTR(-
'Hiiri C/E'-
),UNISTR(-
'Ergonominen, langaton hiiri. Trackball-pallohiiri mukavaan ja helppoon k'||-
'\00e4ytt\00f6\00f6n.'-
));
INSERT INTO product_descriptions VALUES(2056-
,'SF'-
,UNISTR(-
'Hiirialusta /CL'-
),UNISTR(-
'Vakiohiirialusta yrityksen logolla.'-
));
INSERT INTO product_descriptions VALUES(2211-
,'SF'-
,UNISTR(-
'Rannetuki'-
),UNISTR(-
'Vaahtomuovituki ranteita varten n\00e4pp\00e4imist\00f6\00e4 k\00e4yt'||-
'ett\00e4ess\00e4.'-
));
INSERT INTO product_descriptions VALUES(2944-
,'SF'-
,UNISTR(-
'Rannetuki /CL'-
),UNISTR(-
'Rannetuki yrityksen logolla.'-
));
INSERT INTO product_descriptions VALUES(1742-
,'SF'-
,UNISTR(-
'CD-ROM 500/16x'-
),UNISTR(-
'16-nopeuksinen lukeva CD-ROM-asema, enimm\00e4iskapasiteetti 500 Mt.'-
));
INSERT INTO product_descriptions VALUES(2402-
,'SF'-
,UNISTR(-
'CD-ROM 600/E/24x'-
),UNISTR(-
'Ulkoinen 600 megatavun 24-nopeuksinen lukeva CD-ROM-asema.'-
));
INSERT INTO product_descriptions VALUES(2403-
,'SF'-
,UNISTR(-
'CD-ROM 600/I/24x'-
),UNISTR(-
'Sis\00e4inen 600 megatavun 24-nopeuksinen lukeva CD-ROM-asema.'-
));
INSERT INTO product_descriptions VALUES(1761-
,'SF'-
,UNISTR(-
'CD-ROM 600/I/32x'-
),UNISTR(-
'Sis\00e4inen 600 megatavun 32-nopeuksinen lukeva CD-ROM-asema.'-
));
INSERT INTO product_descriptions VALUES(2381-
,'SF'-
,UNISTR(-
'CD-ROM 8x'-
),UNISTR(-
'8-nopeuksinen kirjoittava CD-ROM.'-
));
INSERT INTO product_descriptions VALUES(2424-
,'SF'-
,UNISTR(-
'CDW 12/24'-
),UNISTR(-
'Kirjoittava CD-ROM-asema, 12x kirjoitusnopeus, 24x lukunopeus. Varoitus: m'||-
'alli vanhenee pian, koska nopeudet eiv\00e4t ole en\00e4\00e4 riitt'||-
'\00e4vi\00e4, ja parempia vaihtoehtoja on saatavilla kohtuuhintaan.'-
));
INSERT INTO product_descriptions VALUES(1781-
,'SF'-
,UNISTR(-
'CDW 20/48/E'-
),UNISTR(-
'Kirjoittava CD-ROM-asema, 48x luku, 20x kirjoitus.'-
));
INSERT INTO product_descriptions VALUES(2264-
,'SF'-
,UNISTR(-
'CDW 20/48/I'-
),UNISTR(-
'CD-ROM-asema: 20x luku, 48x kirjoitus (sis\00e4inen)'-
));
INSERT INTO product_descriptions VALUES(2260-
,'SF'-
,UNISTR(-
'DFD 1.44/3.5'-
),UNISTR(-
'Tuplalevykeasema - 1,44 Mt - 3,5 tuumaa.'-
));
INSERT INTO product_descriptions VALUES(2266-
,'SF'-
,UNISTR(-
'DVD 12x'-
),UNISTR(-
'DVD-ROM-asema: 12-nopeuksinen'-
));
INSERT INTO product_descriptions VALUES(3077-
,'SF'-
,UNISTR(-
'DVD 8x'-
),UNISTR(-
'8-nopeuksinen DVD-ROM-asema. Malli vanhenee todenn\00e4k\00f6isesti melk'||-
'o pian...'-
));
INSERT INTO product_descriptions VALUES(2259-
,'SF'-
,UNISTR(-
'Levykeasema 1.44/3.5'-
),UNISTR(-
'Levykeasema - suuritiheyksinen 1,44 Mt - 3,5 tuuman kehikkoon.'-
));
INSERT INTO product_descriptions VALUES(2261-
,'SF'-
,UNISTR(-
'Levykeasema 1.44/3.5/E'-
),UNISTR(-
'Ulkoinen 3,5 tuuman suuritiheyksinen 1,44 megatavun levykeasema.'-
));
INSERT INTO product_descriptions VALUES(3082-
,'SF'-
,UNISTR(-
'Modeemi - 56/90/E'-
),UNISTR(-
'56 kbps modeemi, ITU v.90 PCI-yhteensopiva. Ulkoinen, 110 voltin virtal'||-
'\00e4hteelle.'-
));
INSERT INTO product_descriptions VALUES(2270-
,'SF'-
,UNISTR(-
'Modeemi - 56/90/I'-
),UNISTR(-
'56 Kbps modeemi, ITU v.90 PCI-yhteensopiva. Sis\00e4inen modeemi 3,5 tuum'||-
'an standardikehikkoon.'-
));
INSERT INTO product_descriptions VALUES(2268-
,'SF'-
,UNISTR(-
'Modeemi - 56/H/E'-
),UNISTR(-
'56 kbps ulkoinen Hayes-yhteensopiva vakiomodeemi. Virtal\00e4hde: 220V.'-
));
INSERT INTO product_descriptions VALUES(3083-
,'SF'-
,UNISTR(-
'Modeemi - 56/H/I'-
),UNISTR(-
'Sis\00e4inen 56 kbps Hayes-standardimodeemi 3,5 vakiokehikkoon.'-
));
INSERT INTO product_descriptions VALUES(2374-
,'SF'-
,UNISTR(-
'Modeemi - C/100'-
),UNISTR(-
'DOCSIS/EURODOCSIS 1.0/1.1 -yhteensopiva ulkoinen kaapelimodeemi.'-
));
INSERT INTO product_descriptions VALUES(1740-
,'SF'-
,UNISTR(-
'Nauha-asema 12 Gt/DAT'-
),UNISTR(-
'12 gigatavun DAT-nauha-asema.'-
));
INSERT INTO product_descriptions VALUES(2409-
,'SF'-
,UNISTR(-
'Nauha-asema 7 Gt/8'-
),UNISTR(-
'7 gigatavun nauha-asema 8 mm:n kasettinauhalla.'-
));
INSERT INTO product_descriptions VALUES(2262-
,'SF'-
,UNISTR(-
'ZIP 100'-
),UNISTR(-
'Ulkoinen 100 megatavun ZIP-levyasema ja rinnakkaiskaapeli.'-
));
INSERT INTO product_descriptions VALUES(2522-
,'SF'-
,UNISTR(-
'Akku - EL'-
),UNISTR(-
'Pitk\00e4ik\00e4inen akku sylimikroihin.'-
));
INSERT INTO product_descriptions VALUES(2278-
,'SF'-
,UNISTR(-
'Akku - NiHM'-
),UNISTR(-
'Ladattava NiHM-akku sylimikroihin.'-
));
INSERT INTO product_descriptions VALUES(2418-
,'SF'-
,UNISTR(-
'Vara-akkulaturi (DA-130)'-
),UNISTR(-
'Yhden akun laturi LED-merkkivaloilla.'-
));
INSERT INTO product_descriptions VALUES(2419-
,'SF'-
,UNISTR(-
'Vara-akkulaturi (DA-290)'-
),UNISTR(-
'Kahden akun laturi LED-merkkivaloilla.'-
));
INSERT INTO product_descriptions VALUES(3097-
,'SF'-
,UNISTR(-
'Kaapeliliitin - 32R'-
),UNISTR(-
'32-pinninen nauhakaapeliliitin.'-
));
INSERT INTO product_descriptions VALUES(3099-
,'SF'-
,UNISTR(-
'Kaapeliside'-
),UNISTR(-
'Kaapeliside tietokoneen ja laitteiden johtojen j\00e4rjestelyyn ja sidont'||-
'aan.'-
));
INSERT INTO product_descriptions VALUES(2380-
,'SF'-
,UNISTR(-
'Kaapeli PR/15/P'-
),UNISTR(-
'4,5 metrin rinnakkaistulostinkaapeli.'-
));
INSERT INTO product_descriptions VALUES(2408-
,'SF'-
,UNISTR(-
'Kaapeli PR/P/6'-
),UNISTR(-
'180 cm:n Centronics-standardikaapeli rinnakkaisporttiin.'-
));
INSERT INTO product_descriptions VALUES(2457-
,'SF'-
,UNISTR(-
'Kaapeli PR/S/6'-
),UNISTR(-
'180 cm:n RS232-standardisarjakaapeli tulostimeen.'-
));
INSERT INTO product_descriptions VALUES(2373-
,'SF'-
,UNISTR(-
'Kaapeli RS232 10/AF'-
),UNISTR(-
'3,0 metrin RS232-kaapeli F/F- ja 9F/25F-sovittimilla.'-
));
INSERT INTO product_descriptions VALUES(1734-
,'SF'-
,UNISTR(-
'Kaapeli RS232 10/AM'-
),UNISTR(-
'3,0 metrin RS232-kaapeli M/M- ja 9M/25M-sovittimilla.'-
));
INSERT INTO product_descriptions VALUES(1737-
,'SF'-
,UNISTR(-
'Kaapeli SCSI 10/FW/ADS'-
),UNISTR(-
'3,0 metrin SCSI2, F/W-sovitus DSx000-kaapeliin.'-
));
INSERT INTO product_descriptions VALUES(1745-
,'SF'-
,UNISTR(-
'Kaapeli SCSI 20/WD->D'-
),UNISTR(-
'6,0 metrin SCSI2 Wide Disk Store ->Disk Store -kaapeli.'-
));
INSERT INTO product_descriptions VALUES(2982-
,'SF'-
,UNISTR(-
'Aseman kiinnike - A'-
),UNISTR(-
'Aseman kiinnikkeen rakennussarja.'-
));
INSERT INTO product_descriptions VALUES(3277-
,'SF'-
,UNISTR(-
'Aseman kiinnike - A/T'-
),UNISTR(-
'Aseman kiinnikkeen rakennussarja PC-tornikotelolle.'-
));
INSERT INTO product_descriptions VALUES(2976-
,'SF'-
,UNISTR(-
'Aseman kiinnike - D'-
),UNISTR(-
'Aseman kiinnike p\00f6yt\00e4-PC:lle.'-
));
INSERT INTO product_descriptions VALUES(3204-
,'SF'-
,UNISTR(-
'Envoy DS'-
),UNISTR(-
'Envoy-telakointiasema'-
));
INSERT INTO product_descriptions VALUES(2638-
,'SF'-
,UNISTR(-
'Envoy DS/E'-
),UNISTR(-
'Laajennettu Envoy-telakointiasema'-
));
INSERT INTO product_descriptions VALUES(3020-
,'SF'-
,UNISTR(-
'Envoy IC'-
),UNISTR(-
'Envoy-internet-tietokone, Plug&Play'-
));
INSERT INTO product_descriptions VALUES(1948-
,'SF'-
,UNISTR(-
'Envoy IC/58'-
),UNISTR(-
'Internet-tietokone, jossa sis\00e4\00e4nrakennettu 58 kbps modeemi.'-
));
INSERT INTO product_descriptions VALUES(3003-
,'SF'-
,UNISTR(-
'Kannettava tietokone 128/12/56/v90/110'-
),UNISTR(-
'Envoy-sylimikro, 128 Mt muisti, 12 Gt kiintolevy, v90 modeemi, 110V virtal'||-
'\00e4hde.'-
));
INSERT INTO product_descriptions VALUES(2999-
,'SF'-
,UNISTR(-
'Kannettava tietokone 16/8/110'-
),UNISTR(-
'Envoy-sylimikro, 16 Mt muisti, 8 Gt kiintolevy, 110V virtal\00e4hde (vain'||-
' Yhdysvallat).'-
));
INSERT INTO product_descriptions VALUES(3000-
,'SF'-
,UNISTR(-
'Kannettava tietokone 32/10/56'-
),UNISTR(-
'Envoy-sylimikro, 32 Mt muisti, 10 Gt kiintolevy, 56 kbps modeemi, yleisvir'||-
'tal\00e4hde (j\00e4nnite vaihdettavissa).'-
));
INSERT INTO product_descriptions VALUES(3001-
,'SF'-
,UNISTR(-
'Kannettava tietokone 48/10/56/110'-
),UNISTR(-
'Envoy-sylimikro, 48 Mt muisti, 10 Gt kiintolevy, 56 kbps modeemi, 110V vir'||-
'tal\00e4hde.'-
));
INSERT INTO product_descriptions VALUES(3004-
,'SF'-
,UNISTR(-
'Kannettava tietokone 64/10/56/220'-
),UNISTR(-
'Envoy-sylimikro, 64 Mt muisti, 10 Gt kiintolevy, 56 kbps modeemi, 220V vir'||-
'tal\00e4hde.'-
));
INSERT INTO product_descriptions VALUES(3391-
,'SF'-
,UNISTR(-
'Virtal\00e4hde 110/220'-
),UNISTR(-
'Virtal\00e4hde j\00e4nnitteenvaihtajalla, 110V/220V'-
));
INSERT INTO product_descriptions VALUES(3124-
,'SF'-
,UNISTR(-
'Virtal\00e4hde 110V /T'-
),UNISTR(-
'Virtal\00e4hde PC-tornille, 110V'-
));
INSERT INTO product_descriptions VALUES(1738-
,'SF'-
,UNISTR(-
'Virtal\00e4hde 110V /US'-
),UNISTR(-
'110 voltin virtal\00e4hde, sopii USA:n s\00e4hk\00f6verkkoon.'-
));
INSERT INTO product_descriptions VALUES(2377-
,'SF'-
,UNISTR(-
'Virtal\00e4hde 110V HS/US'-
),UNISTR(-
'110 voltin lennossa vaihdettava virtal\00e4hde, sopii USA:n s\00e4hk'||-
'\00f6verkkoon.'-
));
INSERT INTO product_descriptions VALUES(2299-
,'SF'-
,UNISTR(-
'Virtal\00e4hde 12V /P'-
),UNISTR(-
'12 voltin kannettava virtal\00e4hde.'-
));
INSERT INTO product_descriptions VALUES(3123-
,'SF'-
,UNISTR(-
'Virtal\00e4hde 220V /D'-
),UNISTR(-
'Vakiomallin 220 voltin virtal\00e4hde p\00f6yt\00e4mikroihin.'-
));
INSERT INTO product_descriptions VALUES(1748-
,'SF'-
,UNISTR(-
'Virtal\00e4hde 220V /EUR'-
),UNISTR(-
'220 voltin virtal\00e4hde eurooppalaiseen s\00e4hk\00f6j\00e4rjestelm'||-
'\00e4\00e4n.'-
));
INSERT INTO product_descriptions VALUES(2387-
,'SF'-
,UNISTR(-
'Virtal\00e4hde 220V /FR'-
),UNISTR(-
'220 voltin virtal\00e4hde ranskalaiseen s\00e4hk\00f6j\00e4rjestelm'||-
'\00e4\00e4n.'-
));
INSERT INTO product_descriptions VALUES(2370-
,'SF'-
,UNISTR(-
'Virtal\00e4hde 220V /HS/FR'-
),UNISTR(-
'220 voltin lennossa vaihdettava virtal\00e4hde ranskalaiseen s\00e4hk'||-
'\00f6j\00e4rjestelm\00e4\00e4n.'-
));
INSERT INTO product_descriptions VALUES(2311-
,'SF'-
,UNISTR(-
'Virtal\00e4hde 220V /L'-
),UNISTR(-
'220 voltin virtal\00e4hde kannettaviin tietokoneisiin.'-
));
INSERT INTO product_descriptions VALUES(1733-
,'SF'-
,UNISTR(-
'Virtal\00e4hde 220V /UK'-
),UNISTR(-
'220 voltin virtal\00e4hde Iso-Britannian s\00e4hk\00f6j\00e4rjestelm'||-
'\00e4\00e4n.'-
));
INSERT INTO product_descriptions VALUES(2878-
,'SF'-
,UNISTR(-
'Reititin - ASR/2W'-
),UNISTR(-
'ALS-erikoisreititin - Approved Supplier -tuote - "2-way match".'-
));
INSERT INTO product_descriptions VALUES(2879-
,'SF'-
,UNISTR(-
'Reititin - ASR/3W'-
),UNISTR(-
'ALS-erikoisreititin - Approved Supplier -tuote - "3-way match".'-
));
INSERT INTO product_descriptions VALUES(2152-
,'SF'-
,UNISTR(-
'Reititin - DTMF4'-
),UNISTR(-
'4-porttinen DTMF-reititin.'-
));
INSERT INTO product_descriptions VALUES(3301-
,'SF'-
,UNISTR(-
'Ruuvit <B.28.P>'-
),UNISTR(-
'Ruuvit: Messinki\00e4, koko 28 mm, ristikanta. Muovilaatikossa 500 kpl.'-
));
INSERT INTO product_descriptions VALUES(3143-
,'SF'-
,UNISTR(-
'Ruuvit <B.28.S>'-
),UNISTR(-
'Ruuvit: Messinki\00e4, koko 28 mm, urakanta. Muovilaatikossa 500 kpl.'-
));
INSERT INTO product_descriptions VALUES(2323-
,'SF'-
,UNISTR(-
'Ruuvit <B.32.P>'-
),UNISTR(-
'Ruuvit: Messinki\00e4, koko 32 mm, ristikanta. Muovilaatikossa 400 kpl.'-
));
INSERT INTO product_descriptions VALUES(3134-
,'SF'-
,UNISTR(-
'Ruuvit <B.32.S>'-
),UNISTR(-
'Ruuvit: Messinki\00e4, koko 32 mm, urakanta. Muovilaatikossa 400 kpl.'-
));
INSERT INTO product_descriptions VALUES(3139-
,'SF'-
,UNISTR(-
'Ruuvit <S.16.S>'-
),UNISTR(-
'Ruuvit: Ter\00e4st\00e4, koko 16 mm, urakanta. Pahvilaatikossa 750 kpl.'-
));
INSERT INTO product_descriptions VALUES(3300-
,'SF'-
,UNISTR(-
'Ruuvit <S.32.P>'-
),UNISTR(-
'Ruuvit: Ter\00e4st\00e4, koko 32 mm, ristikanta. Muovilaatikossa 400 kpl'||-
'.'-
));
INSERT INTO product_descriptions VALUES(2316-
,'SF'-
,UNISTR(-
'Ruuvit <S.32.S>'-
),UNISTR(-
'Ruuvit: Ter\00e4st\00e4, koko 32 mm, urakanta. Muovilaatikossa 500 kpl.'-
));
INSERT INTO product_descriptions VALUES(3140-
,'SF'-
,UNISTR(-
'Ruuvit <Z.16.S>'-
),UNISTR(-
'Ruuvit: Sinkittyj\00e4, pituus 16 mm, urakanta. Pahvilaatikossa 750 kpl.'-
));
INSERT INTO product_descriptions VALUES(2319-
,'SF'-
,UNISTR(-
'Ruuvit <Z.24.S>'-
),UNISTR(-
'Ruuvit: Sinkittyj\00e4, koko 24 mm, urakanta. Pahvilaatikossa 500 kpl.'-
));
INSERT INTO product_descriptions VALUES(2322-
,'SF'-
,UNISTR(-
'Ruuvit <Z.28.P>'-
),UNISTR(-
'Ruuvit: Sinkittyj\00e4, koko 28 mm, ristikanta. Pahvilaatikossa 850 kpl.'-
));
INSERT INTO product_descriptions VALUES(3178-
,'SF'-
,UNISTR(-
'Taulukkolaskenta - SSP/V 2.0'-
),UNISTR(-
'SmartSpread-taulukkolaskenta, Professional Edition 2.0, Vision 11.1- ja 11'||-
'.2-versioille. Kutistemuovipakkaus sis\00e4lt\00e4\00e4 CD-ROM-levyn oh'||-
'jelmistoineen ja k\00e4yt\00f6naikaisine dokumentaatioineen, tulostetun '||-
'k\00e4sikirjan, opetusohjelman ja lisenssisopimuksen.'-
));
INSERT INTO product_descriptions VALUES(3179-
,'SF'-
,UNISTR(-
'Taulukkolaskenta - SSS/S 2.1'-
),UNISTR(-
'SmartSpread-taulukkolaskenta, Standard Edition 2.1, SPNIX-versiolle 4.0. K'||-
'utistemuovipakkaus sis\00e4lt\00e4\00e4 CD-ROM-levyn ohjelmistoineen ja'||-
' k\00e4yt\00f6naikaisine dokumentaatioineen, tulostetun k\00e4sikirjan '||-
'ja lisenssisopimuksen.'-
));
INSERT INTO product_descriptions VALUES(3182-
,'SF'-
,UNISTR(-
'Tekstink\00e4sittely - SWP/V 4.5'-
),UNISTR(-
'SmartWord-tekstink\00e4sittelyohjelma, Professional Edition 4.5, Vision-v'||-
'ersiolle 11.x. Kutistemuovipakkaus sis\00e4lt\00e4\00e4 CD-ROM-levyn oh'||-
'jelmistoineen, tulostetun k\00e4sikirjan ja lisenssisopimuksen.'-
));
INSERT INTO product_descriptions VALUES(3183-
,'SF'-
,UNISTR(-
'Tekstink\00e4sittely - SWS/V 4.5'-
),UNISTR(-
'SmartWord-tekstink\00e4sittelyohjelma, Standard Edition 4.5, Vision-versi'||-
'olle 11.x. Kutistemuovipakkaus sis\00e4lt\00e4\00e4 CD-ROM-levyn ja lis'||-
'enssisopimuksen.'-
));
INSERT INTO product_descriptions VALUES(3197-
,'SF'-
,UNISTR(-
'Taulukkolaskenta - SSS/V 2.1'-
),UNISTR(-
'SmartSpread-taulukkolaskentaohjelma, Standard Edition 2.1, Vision 11.1- ja'||-
' 11.2-versioille. Kutistemuovipakkaus sis\00e4lt\00e4\00e4 CD-ROM-levyn'||-
' ohjelmistoineen ja k\00e4yt\00f6naikaisine dokumentaatioineen, tulostet'||-
'un k\00e4sikirjan, opetusohjelman ja lisenssisopimuksen.'-
));
INSERT INTO product_descriptions VALUES(3255-
,'SF'-
,UNISTR(-
'Taulukkolaskenta - SSS/CD 2.2B'-
),UNISTR(-
'SmartSpread -taulukkolaskenta, Standard Edition Beta 2.2, SPNIX-versiolle '||-
'4.1. Vain CD-ROM-levy.'-
));
INSERT INTO product_descriptions VALUES(3256-
,'SF'-
,UNISTR(-
'Taulukkolaskenta - SSS/V 2.0'-
),UNISTR(-
'SmartSpread-taulukkolaskenta, Standard Edition 2.0, Vision-versiolle 11.0.'||-
' Kutistemuovipakkaus sis\00e4lt\00e4\00e4 CD-ROM-levyn ohjelmistoineen '||-
'ja k\00e4yt\00f6naikaisine dokumentaatioineen, tulostetun k\00e4sikirja'||-
'n, opetusohjelman ja lisenssisopimuksen.'-
));
INSERT INTO product_descriptions VALUES(3260-
,'SF'-
,UNISTR(-
'Tekstink\00e4sittely - SWP/S 4.4'-
),UNISTR(-
'SmartSpread-taulukkolaskenta, Standard Edition 2.2, SPNIX-versiolle 4.x. K'||-
'utistemuovipakkaus sis\00e4lt\00e4\00e4 CD-ROM-levyn ohjelmistoineen, t'||-
'ulostetun k\00e4sikirjan ja lisenssisopimuksen.'-
));
INSERT INTO product_descriptions VALUES(3262-
,'SF'-
,UNISTR(-
'Taulukkolaskenta - SSS/S 2.2'-
),UNISTR(-
'SmartSpread-taulukkolaskenta, Standard Edition 2.2, SPNIX-versiolle 4.1. K'||-
'utistemuovipakkaus sis\00e4lt\00e4\00e4 CD-ROM-levyn ohjelmistoineen ja'||-
' k\00e4yt\00f6naikaisine dokumentaatioineen, tulostetun k\00e4sikirjan '||-
'ja lisenssisopimuksen.'-
));
INSERT INTO product_descriptions VALUES(3361-
,'SF'-
,UNISTR(-
'Taulukkolaskenta - SSP/S 1.5'-
),UNISTR(-
'SmartSpread-taulukkolaskenta, Standard Edition 1.5, SPNIX-versiolle 3.3. K'||-
'utistemuovipakkaus sis\00e4lt\00e4\00e4 CD-ROM-levyn ohjelmistoineen ja'||-
' k\00e4yt\00f6naikaisine dokumentaatioineen, tulostetun k\00e4sikirjan,'||-
' opetusohjelman ja lisenssisopimuksen.'-
));
INSERT INTO product_descriptions VALUES(1799-
,'SF'-
,UNISTR(-
'SPNIX3.3 - SL'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V3.3 - Peruspalveli'||-
'nlisenssi. Sis\00e4lt\00e4\00e4 10 yleislisenssi\00e4 j\00e4rjestelm'||-
'\00e4nhallintaan, kehitt\00e4jille tai k\00e4ytt\00e4jille. Ei verkkok'||-
'\00e4ytt\00e4j\00e4lisenssi\00e4.'-
));
INSERT INTO product_descriptions VALUES(1801-
,'SF'-
,UNISTR(-
'SPNIX3.3 - AL'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V3.3 - J\00e4rjest'||-
'elm\00e4nvalvojan lis\00e4lisenssi, jossa on verkkok\00e4ytt\00f6oikeu'||-
's.'-
));
INSERT INTO product_descriptions VALUES(1803-
,'SF'-
,UNISTR(-
'SPNIX3.3 - DL'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V3.3 - Kehitt\00e4'||-
'j\00e4n lis\00e4lisenssi.'-
));
INSERT INTO product_descriptions VALUES(1804-
,'SF'-
,UNISTR(-
'SPNIX3.3 - UL/N'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V3.3 - K\00e4ytt'||-
'\00e4j\00e4n lis\00e4lisenssi, jossa on verkkok\00e4ytt\00f6oikeus.'-
));
INSERT INTO product_descriptions VALUES(1805-
,'SF'-
,UNISTR(-
'SPNIX3.3 - UL/A'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V3.3 - A-luokan lis'||-
'\00e4k\00e4ytt\00e4j\00e4lisenssi.'-
));
INSERT INTO product_descriptions VALUES(1806-
,'SF'-
,UNISTR(-
'SPNIX3.3 - UL/C'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V3.3 - C-luokan lis'||-
'\00e4k\00e4ytt\00e4j\00e4lisenssi.'-
));
INSERT INTO product_descriptions VALUES(1808-
,'SF'-
,UNISTR(-
'SPNIX3.3 - UL/D'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V3.3 - D-luokan lis'||-
'\00e4k\00e4ytt\00e4j\00e4lisenssi.'-
));
INSERT INTO product_descriptions VALUES(1820-
,'SF'-
,UNISTR(-
'SPNIX3.3 - NL'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V3.3 - lis\00e4ver'||-
'kkolisenssi.'-
));
INSERT INTO product_descriptions VALUES(1822-
,'SF'-
,UNISTR(-
'SPNIX4.0 - SL'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V3.3 - Peruspalveli'||-
'nlisenssi. Sis\00e4lt\00e4\00e4 10 yleislisenssi\00e4 j\00e4rjestelm'||-
'\00e4nhallintaan, kehitt\00e4jille tai k\00e4ytt\00e4jille. Ei verkkok'||-
'\00e4ytt\00e4j\00e4lisenssi\00e4.'-
));
INSERT INTO product_descriptions VALUES(2422-
,'SF'-
,UNISTR(-
'SPNIX4.0 - SAL'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V4.0 - J\00e4rjest'||-
'elm\00e4nvalvojan lis\00e4lisenssi, jossa on verkkok\00e4ytt\00f6oikeu'||-
's.'-
));
INSERT INTO product_descriptions VALUES(2452-
,'SF'-
,UNISTR(-
'SPNIX4.0 - DL'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V4.0 - Kehitt\00e4'||-
'j\00e4n lis\00e4lisenssi.'-
));
INSERT INTO product_descriptions VALUES(2462-
,'SF'-
,UNISTR(-
'SPNIX4.0 - UL/N'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V4.0 - K\00e4ytt'||-
'\00e4j\00e4n lis\00e4lisenssi, jossa on verkkok\00e4ytt\00f6oikeus.'-
));
INSERT INTO product_descriptions VALUES(2464-
,'SF'-
,UNISTR(-
'SPNIX4.0 - UL/A'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V4.0 - A-luokan lis'||-
'\00e4k\00e4ytt\00e4j\00e4lisenssi.'-
));
INSERT INTO product_descriptions VALUES(2467-
,'SF'-
,UNISTR(-
'SPNIX4.0 - UL/D'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V4.0 - D-luokan lis'||-
'\00e4k\00e4ytt\00e4j\00e4lisenssi.'-
));
INSERT INTO product_descriptions VALUES(2468-
,'SF'-
,UNISTR(-
'SPNIX4.0 - UL/C'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V4.0 - C-luokan lis'||-
'\00e4k\00e4ytt\00e4j\00e4lisenssi.'-
));
INSERT INTO product_descriptions VALUES(2470-
,'SF'-
,UNISTR(-
'SPNIX4.0 - NL'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V4.0 - lis\00e4ver'||-
'kkolisenssi.'-
));
INSERT INTO product_descriptions VALUES(2471-
,'SF'-
,UNISTR(-
'SPNIX3.3 SU'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V3.3 - Peruspalveli'||-
'nlisenssin p\00e4ivitys versioon 4.0.'-
));
INSERT INTO product_descriptions VALUES(2492-
,'SF'-
,UNISTR(-
'SPNIX3.3 AU'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V3.3 - V4.0 -p'||-
'\00e4ivitys, A-luokan k\00e4ytt\00e4j\00e4.'-
));
INSERT INTO product_descriptions VALUES(2493-
,'SF'-
,UNISTR(-
'SPNIX3.3 C/DU'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V3.3 - V4.0 -p'||-
'\00e4ivitys, C- tai D-luokan k\00e4ytt\00e4j\00e4.'-
));
INSERT INTO product_descriptions VALUES(2494-
,'SF'-
,UNISTR(-
'SPNIX3.3 NU'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V3.3 - V4.0 -p'||-
'\00e4ivitys, verkkok\00e4ytt\00f6lisenssi.'-
));
INSERT INTO product_descriptions VALUES(2995-
,'SF'-
,UNISTR(-
'SPNIX3.3 SAU'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V3.3 - V4.0 -p'||-
'\00e4ivitys, j\00e4rjestelm\00e4nvalvojan lisenssi.'-
));
INSERT INTO product_descriptions VALUES(3290-
,'SF'-
,UNISTR(-
'SPNIX3.3 DU'-
),UNISTR(-
'K\00e4ytt\00f6j\00e4rjestelm\00e4ohjelmisto: SPNIX V3.3 - V4.0 -p'||-
'\00e4ivitys, kehitt\00e4j\00e4n lisenssi.'-
));
INSERT INTO product_descriptions VALUES(1778-
,'SF'-
,UNISTR(-
'C for SPNIX3.3 - 1 k\00e4ytt\00e4j\00e4'-
),UNISTR(-
'Yhden k\00e4ytt\00e4j\00e4n C-ohjelmointikielen ohjelmisto SPNIX-versio'||-
'lle 3.3.'-
));
INSERT INTO product_descriptions VALUES(1779-
,'SF'-
,UNISTR(-
'C for SPNIX3.3 - Dokumentaatio'-
),UNISTR(-
'C-ohjelmointikielen dokumentaatio, SPNIX V3.3'-
));
INSERT INTO product_descriptions VALUES(1780-
,'SF'-
,UNISTR(-
'C for SPNIX3.3 - Sys'-
),UNISTR(-
'C-ohjelmointikielen ohjelmisto SPNIX-versiolle 3.3 - j\00e4rjestelm\00e4'||-
'k\00e4\00e4nt\00e4j\00e4, kirjastot ja linkitt\00e4j\00e4.'-
));
INSERT INTO product_descriptions VALUES(2371-
,'SF'-
,UNISTR(-
'C for SPNIX4.0 - Dokumentaatio'-
),UNISTR(-
'C-ohjelmointikielen dokumentaatio, SPNIX V4.0'-
));
INSERT INTO product_descriptions VALUES(2423-
,'SF'-
,UNISTR(-
'C for SPNIX4.0 - 1 k\00e4ytt\00e4j\00e4'-
),UNISTR(-
'Yhden k\00e4ytt\00e4j\00e4n C-ohjelmointikielen ohjelmisto SPNIX-versio'||-
'lle 4.0.'-
));
INSERT INTO product_descriptions VALUES(3501-
,'SF'-
,UNISTR(-
'C for SPNIX4.0 - Sys'-
),UNISTR(-
'C-ohjelmointikielen ohjelmisto SPNIX-versiolle 4.0 - j\00e4rjestelm\00e4'||-
'k\00e4\00e4nt\00e4j\00e4, kirjastot ja linkitt\00e4j\00e4.'-
));
INSERT INTO product_descriptions VALUES(3502-
,'SF'-
,UNISTR(-
'C for SPNIX3.3 - Sys/U'-
),UNISTR(-
'C-ohjelmointikielen ohjelmisto SPNIX V3.3 - 4.0 -p\00e4ivitykselle: j'||-
'\00e4rjestelm\00e4k\00e4\00e4nt\00e4j\00e4, kirjastot ja linkitt'||-
'\00e4j\00e4.'-
));
INSERT INTO product_descriptions VALUES(3503-
,'SF'-
,UNISTR(-
'C for SPNIX3.3 - Seat/U'-
),UNISTR(-
'Yhden k\00e4ytt\00e4j\00e4n C-ohjelmointikielen ohjelmisto SPNIX V3.3 -'||-
' 4.0 -p\00e4ivitykselle.'-
));
INSERT INTO product_descriptions VALUES(1774-
,'SF'-
,UNISTR(-
'Perus-ISO CP - BL'-
),UNISTR(-
'Perus-ISO -tietoliikennepaketti, peruslisenssi'-
));
INSERT INTO product_descriptions VALUES(1775-
,'SF'-
,UNISTR(-
'Asiakas-ISO CP - S'-
),UNISTR(-
'ISO-tietoliikennepaketin lis\00e4lisenssi SPNIX V3.3 -asiakkaalle.'-
));
INSERT INTO product_descriptions VALUES(1794-
,'SF'-
,UNISTR(-
'OSI 8-16/IL'-
),UNISTR(-
'OSI-kerros 8-16 - Lis\00e4lisenssi.'-
));
INSERT INTO product_descriptions VALUES(1825-
,'SF'-
,UNISTR(-
'X25 - 1 linjalisenssi'-
),UNISTR(-
'Yhden k\00e4ytt\00e4j\00e4n X25-verkkok\00e4yt\00f6n valvontaj\00e4r'||-
'jestelm\00e4.'-
));
INSERT INTO product_descriptions VALUES(2004-
,'SF'-
,UNISTR(-
'IC-selain - S'-
),UNISTR(-
'IC Web Browser for SPNIX -web-selain. Selain, jossa on verkkopostimahdolli'||-
'suus.'-
));
INSERT INTO product_descriptions VALUES(2005-
,'SF'-
,UNISTR(-
'IC-selaimen dokumentointi - S'-
),UNISTR(-
'IC Web Browser for SPNIX -web-selaimen dokumentaatiopaketti. Sis\00e4lt'||-
'\00e4\00e4 asennusoppaan, s\00e4hk\00f6postipalvelimen yll\00e4pito-o'||-
'ppaan ja k\00e4ytt\00e4j\00e4n pikaoppaan.'-
));
INSERT INTO product_descriptions VALUES(2416-
,'SF'-
,UNISTR(-
'Asiakas-ISO CP - S'-
),UNISTR(-
'ISO-tietoliikennepaketin lis\00e4lisenssi SPNIX V4.0 -asiakkaalle.'-
));
INSERT INTO product_descriptions VALUES(2417-
,'SF'-
,UNISTR(-
'Asiakas-ISO CP - V'-
),UNISTR(-
'ISO-tietoliikennepaketin lis\00e4lisenssi Vision-asiakkaalle.'-
));
INSERT INTO product_descriptions VALUES(2449-
,'SF'-
,UNISTR(-
'OSI 1-4/IL'-
),UNISTR(-
'OSI-kerros 1-4 - Lis\00e4lisenssi.'-
));
INSERT INTO product_descriptions VALUES(3101-
,'SF'-
,UNISTR(-
'IC-selain - V'-
),UNISTR(-
'IC Web Browser for Vision -web-selain ja k\00e4sikirja. Selain, jossa on '||-
'verkkopostimahdollisuus.'-
));
INSERT INTO product_descriptions VALUES(3170-
,'SF'-
,UNISTR(-
'Smart Suite - V/SP'-
),UNISTR(-
'Toimisto-ohjelmakokonaisuus (SmartWrite, SmartArt, SmartSpread ja SmartBro'||-
'wse) Vision-j\00e4rjestelm\00e4\00e4n. Espanjankielinen ohjelmisto ja k'||-
'\00e4ytt\00f6oppaat.'-
));
INSERT INTO product_descriptions VALUES(3171-
,'SF'-
,UNISTR(-
'Smart Suite - S3.3/EN'-
),UNISTR(-
'Toimisto-ohjelmakokonaisuus (SmartWrite, SmartArt, SmartSpread ja SmartBro'||-
'wse) SPNIX V3.3 -j\00e4rjestelm\00e4\00e4n. Englanninkielinen ohjelmist'||-
'o ja k\00e4ytt\00f6oppaat.'-
));
INSERT INTO product_descriptions VALUES(3172-
,'SF'-
,UNISTR(-
'Grafiikka - DIK+'-
),UNISTR(-
'Software Kit Graphics: Draw-It Kwik-Plus. Pakettiin kuuluvat kattavat leik'||-
'ekuvatiedostot ja edistyneet piirtoty\00f6kalut 3D-objekteille, erilaisia'||-
' varjostusmahdollisuuksia ja laajennetut merkist\00f6fontit.'-
));
INSERT INTO product_descriptions VALUES(3173-
,'SF'-
,UNISTR(-
'Grafiikka - SA'-
),UNISTR(-
'Software Kit Graphics: SmartArt. Ammattilaistason grafiikkapaketti SPNIX-j'||-
'\00e4rjestelm\00e4\00e4n. Ohjelman ominaisuuksina mm. useita viivatyyle'||-
'j\00e4, tekstuureja, valmiita muotoja ja yleisesti k\00e4ytettyj\00e4 s'||-
'ymboleja.'-
));
INSERT INTO product_descriptions VALUES(3175-
,'SF'-
,UNISTR(-
'Projektinhallinta - S4.0'-
),UNISTR(-
'Projektinhallintaohjelmisto SPNIX V4.0:lle. Ohjelmisto sis\00e4lt\00e4'||-
'\00e4 komentorivi- ja graafisen k\00e4ytt\00f6liittym\00e4n, joissa k'||-
'\00e4ytett\00e4viss\00e4 teksti-, grafiikka-, taulukkolaskenta- ja muok'||-
'attavat raporttiformaatit.'-
));
INSERT INTO product_descriptions VALUES(3176-
,'SF'-
,UNISTR(-
'Smart Suite - V/EN'-
),UNISTR(-
'Toimisto-ohjelmakokonaisuus (SmartWrite, SmartArt, SmartSpread ja SmartBro'||-
'wse) Vision-j\00e4rjestelm\00e4\00e4n. Englanninkielinen ohjelmisto ja '||-
'k\00e4ytt\00f6oppaat.'-
));
INSERT INTO product_descriptions VALUES(3177-
,'SF'-
,UNISTR(-
'Smart Suite - V/FR'-
),UNISTR(-
'Toimisto-ohjelmakokonaisuus (SmartWrite, SmartArt, SmartSpread ja SmartBro'||-
'wse) Vision-j\00e4rjestelm\00e4\00e4n. Ranskankielinen ohjelmisto ja k'||-
'\00e4ytt\00f6oppaat.'-
));
INSERT INTO product_descriptions VALUES(3245-
,'SF'-
,UNISTR(-
'Smart Suite - S4.0/FR'-
),UNISTR(-
'Toimisto-ohjelmakokonaisuus (SmartWrite, SmartArt, SmartSpread ja SmartBro'||-
'wse) SPNIX V4.0 -j\00e4rjestelm\00e4\00e4n. Ranskankielinen ohjelmisto '||-
'ja k\00e4ytt\00f6oppaat.'-
));
INSERT INTO product_descriptions VALUES(3246-
,'SF'-
,UNISTR(-
'Smart Suite - S4.0/SP'-
),UNISTR(-
'Toimisto-ohjelmakokonaisuus (SmartWrite, SmartArt, SmartSpread ja SmartBro'||-
'wse) SPNIX V4.0 -j\00e4rjestelm\00e4\00e4n. Espanjankielinen ohjelmisto'||-
' ja k\00e4ytt\00f6oppaat.'-
));
INSERT INTO product_descriptions VALUES(3247-
,'SF'-
,UNISTR(-
'Smart Suite - V/DE'-
),UNISTR(-
'Toimisto-ohjelmakokonaisuus (SmartWrite, SmartArt, SmartSpread ja SmartBro'||-
'wse) Vision-j\00e4rjestelm\00e4\00e4n. Saksankielinen ohjelmisto ja k'||-
'\00e4ytt\00f6oppaat.'-
));
INSERT INTO product_descriptions VALUES(3248-
,'SF'-
,UNISTR(-
'Smart Suite - S4.0/DE'-
),UNISTR(-
'Toimisto-ohjelmakokonaisuus (SmartWrite, SmartArt, SmartSpread ja SmartBro'||-
'wse) SPNIX V4.0 -j\00e4rjestelm\00e4\00e4n. Saksankielinen ohjelmisto j'||-
'a k\00e4ytt\00f6oppaat.'-
));
INSERT INTO product_descriptions VALUES(3250-
,'SF'-
,UNISTR(-
'Grafiikka - DIK'-
),UNISTR(-
'Software Kit Graphics: Draw-It Kwik. Yksinkertainen grafiikkapaketti Visio'||-
'n-j\00e4rjestelmiin. Ohjelman ominaisuuksina mm. tallennus GIF-, JPG- ja '||-
'BMP-kuvatiedostoiksi.'-
));
INSERT INTO product_descriptions VALUES(3251-
,'SF'-
,UNISTR(-
'Projektinhallinta - V'-
),UNISTR(-
'Projektinhallintaohjelmisto Vision-j\00e4rjestelm\00e4\00e4n. Ohjelmist'||-
'o sis\00e4lt\00e4\00e4 komentorivi- ja graafisen k\00e4ytt\00f6liitty'||-
'm\00e4n, joissa k\00e4ytett\00e4viss\00e4 teksti-, grafiikka-, taulukk'||-
'olaskenta- ja muokattavat raporttiformaatit.'-
));
INSERT INTO product_descriptions VALUES(3252-
,'SF'-
,UNISTR(-
'Projektinhallinta - S3.3'-
),UNISTR(-
'Projektinhallintaohjelmisto SPNIX V3.3:lle. Ohjelmisto sis\00e4lt\00e4'||-
'\00e4 komentorivi- ja graafisen k\00e4ytt\00f6liittym\00e4n, joissa k'||-
'\00e4ytett\00e4viss\00e4 teksti-, grafiikka-, taulukkolaskenta- ja muok'||-
'attavat raporttiformaatit.'-
));
INSERT INTO product_descriptions VALUES(3253-
,'SF'-
,UNISTR(-
'Smart Suite - S4.0/EN'-
),UNISTR(-
'Toimisto-ohjelmakokonaisuus (SmartWrite, SmartArt, SmartSpread ja SmartBro'||-
'wse) SPNIX V4.0 -j\00e4rjestelm\00e4\00e4n. Englanninkielinen ohjelmist'||-
'o ja k\00e4ytt\00f6oppaat.'-
));
INSERT INTO product_descriptions VALUES(3257-
,'SF'-
,UNISTR(-
'Web-selain - SB/S 2.1'-
),UNISTR(-
'Web-selainohjelmistopaketti: SmartBrowse V2.1 for SPNIX V3.3 -ohjelmisto. '||-
'Sis\00e4lt\00e4\00e4 kontekstiriippuvaiset ohjetiedostot ja k\00e4yt'||-
'\00f6naikaisen dokumentaation.'-
));
INSERT INTO product_descriptions VALUES(3258-
,'SF'-
,UNISTR(-
'Web-selain - SB/V 1.0'-
),UNISTR(-
'Web-selainohjelmistopaketti: SmartBrowse V2.1 for Vision -ohjelmisto. Sis'||-
'\00e4lt\00e4\00e4 kontekstiriippuvaiset ohjetiedostot ja k\00e4yt'||-
'\00f6naikaisen dokumentaation.'-
));
INSERT INTO product_descriptions VALUES(3362-
,'SF'-
,UNISTR(-
'Web-selain - SB/S 4.0'-
),UNISTR(-
'Web-selainohjelmistopaketti: SmartBrowse V4.0 for SPNIX V4.0 -ohjelmisto. '||-
'Sis\00e4lt\00e4\00e4 kontekstiriippuvaiset ohjetiedostot ja k\00e4yt'||-
'\00f6naikaisen dokumentaation.'-
));
INSERT INTO product_descriptions VALUES(2231-
,'SF'-
,UNISTR(-
'Ty\00f6p\00f6yt\00e4 - S/V'-
),UNISTR(-
'P\00e4\00e4omitus- ja verotuskelpoinen standardikokoinen ty\00f6p\00f6'||-
'yt\00e4. Pintamateriaali tilauksen aikana varastossa olevasta valikoimast'||-
'a: tammi, saarni, kirsikka tai mahonki.'-
));
INSERT INTO product_descriptions VALUES(2335-
,'SF'-
,UNISTR(-
'Matkapuhelin'-
),UNISTR(-
'V\00e4h\00e4virtainen kaksitaajuusmatkapuhelin. Kevyt, taitettava, yhden'||-
' kuulokkeen liit\00e4nt\00e4 ja vara-akkukotelo.'-
));
INSERT INTO product_descriptions VALUES(2350-
,'SF'-
,UNISTR(-
'Ty\00f6p\00f6yt\00e4 - W/48'-
),UNISTR(-
'Ty\00f6p\00f6yt\00e4 - 122 cm valkoinen laminaattikansi (p\00e4\00e4o'||-
'mitettava, verotettava tuote).'-
));
INSERT INTO product_descriptions VALUES(2351-
,'SF'-
,UNISTR(-
'Ty\00f6p\00f6yt\00e4 - W/48/R'-
),UNISTR(-
'Ty\00f6p\00f6yt\00e4 -152 cm:n valkoinen laminaattikansi 122 cm:n taite'||-
'ttavalla osalla (p\00e4\00e4omitettava, verotettava tuote).'-
));
INSERT INTO product_descriptions VALUES(2779-
,'SF'-
,UNISTR(-
'Ty\00f6p\00f6yt\00e4 - OS/O/F'-
),UNISTR(-
'Johtajatyylinen massiivitammip\00f6yt\00e4, jossa arkistolaatikot. Lopul'||-
'linen pintak\00e4sittely voidaan valita tilattaessa: joko vaalea tai tumm'||-
'a tammipetsi tai k\00e4sin hangattu kirkas puunv\00e4rinen pinta.'-
));
INSERT INTO product_descriptions VALUES(3337-
,'SF'-
,UNISTR(-
'Kannettava Web-puhelin'-
),UNISTR(-
'Kannettava puhelin, jossa kuukausittainen internet-k\00e4ytt\00f6maksu. '||-
'Sulavalinjaiset muodot, nahkaj\00e4ljitelm\00e4kotelo ja vy\00f6klipsi.'-
));
INSERT INTO product_descriptions VALUES(2091-
,'SF'-
,UNISTR(-
'Paperitabletti LW 8 1/2 x 11'-
),UNISTR(-
'Viivoitettu paperitabletti, koko 21,59 x 27,94 cm.'-
));
INSERT INTO product_descriptions VALUES(2093-
,'SF'-
,UNISTR(-
'Kyn\00e4t - 10/FP'-
),UNISTR(-
'Pysyv\00e4 muste kuivuu nopeasti eik\00e4 tahraannu. Sujuvaa, katkotonta'||-
' kirjoittamista. Hieno k\00e4rki. Yksiv\00e4risten kynien rasia (v\00e4'||-
'rit musta, sininen tai punainen) tai eriv\00e4risten kynien rasia (6 must'||-
'aa, 3 sinist\00e4 ja 1 punainen).'-
));
INSERT INTO product_descriptions VALUES(2144-
,'SF'-
,UNISTR(-
'Korttitelineen kansi'-
),UNISTR(-
'Vaihtokansi ty\00f6p\00f6yd\00e4n k\00e4yntikorttitelineelle. Savunhar'||-
'maa (alkuper\00e4inen v\00e4ri) tai kirkas muovi.'-
));
INSERT INTO product_descriptions VALUES(2336-
,'SF'-
,UNISTR(-
'K\00e4yntikorttilaatikko - 250'-
),UNISTR(-
'K\00e4yntikorttilaatikko 250 kortille. K\00e4yt\00e4 tilattaessa lomake'||-
'tta BC110-2, Rev. 3/2000 (paperikopio tai elektroninen), t\00e4ytt\00e4e'||-
'n kaikki t\00e4hdell\00e4 merkityt kent\00e4t.'-
));
INSERT INTO product_descriptions VALUES(2337-
,'SF'-
,UNISTR(-
'Yrityskortit - 1000/2L'-
),UNISTR(-
'Yrityskorttilaatikko 1000 kortille. Kaksipuoliset, eri kielet kummallakin '||-
'puolella. K\00e4yt\00e4 tilattaessa lomaketta BC111-2, Rev. 12/1999 (pap'||-
'erikopio tai elektroninen), t\00e4ytt\00e4en kaikki t\00e4hdell\00e4 m'||-
'erkityt kent\00e4t ja valintaruutu toista kielt\00e4 varten (englanti ai'||-
'na 1-puolella).'-
));
INSERT INTO product_descriptions VALUES(2339-
,'SF'-
,UNISTR(-
'Paperi - Vakiotulostin'-
),UNISTR(-
'9 kg 21,59 x 27,94 (Letter-koko) valkoista lasertulostinpaperia (kierr'||-
'\00e4tetty), 10 kpl 500 arkin riiseiss\00e4.'-
));
INSERT INTO product_descriptions VALUES(2536-
,'SF'-
,UNISTR(-
'Yrityskortit -250/2L'-
),UNISTR(-
'Yrityskorttilaatikko 250 kortille. Kaksipuoliset, eri kielet kummallakin p'||-
'uolella. K\00e4yt\00e4 tilattaessa lomaketta BC111-2, Rev. 12/1999 (pape'||-
'rikopio tai elektroninen), t\00e4ytt\00e4en kaikki t\00e4hdell\00e4 me'||-
'rkityt kent\00e4t ja valintaruutu toista kielt\00e4 varten (englanti ain'||-
'a 1-puolella).'-
));
INSERT INTO product_descriptions VALUES(2537-
,'SF'-
,UNISTR(-
'Yrityskorttilaatikko -1000'-
),UNISTR(-
'Yrityskorttilaatikko 1000 kortille. K\00e4yt\00e4 tilattaessa lomaketta '||-
'BC110-3, Rev. 3/2000 (paperikopio tai elektroninen), t\00e4ytt\00e4en ka'||-
'ikki t\00e4hdell\00e4 merkityt kent\00e4t.'-
));
INSERT INTO product_descriptions VALUES(2783-
,'SF'-
,UNISTR(-
'Paperiliittimet - Paperi'-
),UNISTR(-
'Maailmankuulut paperiliittimet ovat taattua laatua. 10 rasiaa, joissa joka'||-
'isessa 100 liitint\00e4. #1 tavallinen tai j\00e4ttikoko, sile\00e4 tai'||-
' luistamaton.'-
));
INSERT INTO product_descriptions VALUES(2808-
,'SF'-
,UNISTR(-
'Paperitabletti LY 8 1/2 x 11'-
),UNISTR(-
'Viivoitettu paperitabletti, koko 21,59 x 27,94 cm (8 1/2 x 11 tuumaa), v'||-
'\00e4ri keltainen.'-
));
INSERT INTO product_descriptions VALUES(2810-
,'SF'-
,UNISTR(-
'Inkvisible-kyn\00e4t'-
),UNISTR(-
'Kuulak\00e4rkikyn\00e4ss\00e4 luistava tarkkuusk\00e4rki. L\00e4pin'||-
'\00e4kyv\00e4st\00e4 varresta voidaan n\00e4hd\00e4 musteen m\00e4'||-
'\00e4r\00e4, ja kuminen tarttumapinta varmistaa pit\00e4v\00e4n otteen'||-
'. 4 kappaleen rasia, jossa v\00e4rit musta, sininen, punainen ja vihre'||-
'\00e4.'-
));
INSERT INTO product_descriptions VALUES(2870-
,'SF'-
,UNISTR(-
'T\00e4ytekyn\00e4 - Mech'-
),UNISTR(-
'Ergonomisesti suunniteltu mekaaninen kyn\00e4, jonka kirjoitusmukavuutta '||-
'on parannettu. Vaihdettavat pyyhekumit ja lyijyt. Kolme eri kokoa: 0,5 mm '||-
'(ohut) - 0,7 mm (keskipaksu) - 0,9 mm (paksu).'-
));
INSERT INTO product_descriptions VALUES(3051-
,'SF'-
,UNISTR(-
'Kyn\00e4t - 10/MP'-
),UNISTR(-
'Pysyv\00e4 muste kuivuu nopeasti eik\00e4 tahraannu. Sujuvaa, katkotonta'||-
' kirjoittamista. Keskipaksu k\00e4rki. Yksiv\00e4risten kynien rasia (v'||-
'\00e4rit musta, sininen tai punainen) tai eriv\00e4risten kynien rasia ('||-
'6 mustaa, 3 sinist\00e4 ja 1 punainen).'-
));
INSERT INTO product_descriptions VALUES(3150-
,'SF'-
,UNISTR(-
'Korttiteline - 25'-
),UNISTR(-
'Korttiteline yrityskorteille kest\00e4v\00e4st\00e4 muovista, varustett'||-
'una upotetulla yrityksen logolla. Noin 25:lle kortille, riippuen korttien '||-
'paksuudesta.'-
));
INSERT INTO product_descriptions VALUES(3208-
,'SF'-
,UNISTR(-
'Kyn\00e4t - Puu'-
),UNISTR(-
'24 kpl:een rasia puisia kyni\00e4. Anna lyijyn tyyppi tilattaessa: 2H (tu'||-
'plakova), H (kova), HB (kova musta), B (pehme\00e4 musta).'-
));
INSERT INTO product_descriptions VALUES(3209-
,'SF'-
,UNISTR(-
'Kyn\00e4nteroitin'-
),UNISTR(-
'S\00e4hk\00f6inen kyn\00e4nteroitin pitk\00e4ik\00e4isill\00e4 ter'||-
'\00e4sterill\00e4. PencilSaver-ominaisuus est\00e4\00e4 liiallisen ter'||-
'oituksen. Luistamattomat kumitassut. Kyn\00e4teline laitteessa.'-
));
INSERT INTO product_descriptions VALUES(3224-
,'SF'-
,UNISTR(-
'Korttiteline - 250'-
),UNISTR(-
'Kannettava teline yrityskorttien j\00e4rjestyksess\00e4 pit\00e4miseen.'||-
' 250 korttia. Kirjatyylinen ulkoasu, l\00e4pin\00e4kyv\00e4t pujotustas'||-
'kut yrityskorteille. Valinnaiset aakkostetut v\00e4lilehdet. Anna kannen '||-
'v\00e4ri tilattaessa (tummanruskea, beesi, punaruskea, musta ja vaaleanha'||-
'rmaa).'-
));
INSERT INTO product_descriptions VALUES(3225-
,'SF'-
,UNISTR(-
'Korttiteline -1000'-
),UNISTR(-
'Yrityskorttiteline aakkoserottimin 1000 kortille. Ty\00f6p\00f6yt\00e4m'||-
'allinen, savunharmaa kansi ja musta pohja. Kansi voidaan ottaa pois tarvit'||-
'taessa.'-
));
INSERT INTO product_descriptions VALUES(3511-
,'SF'-
,UNISTR(-
'Paperi - Laatutulostin'-
),UNISTR(-
'Laatuluokan paperi mustesuihku- ja lasertulostimiin. Testattu paperitukoks'||-
'ia vastaan. Happovapaa, arkistointikelpoinen paperi. 9 kg, vaaleus 92, kok'||-
'o: 21,59 x 27,94 cm (8 1/2 x 11 tuumaa). Yksi 500 kpl:een riisi.'-
));
INSERT INTO product_descriptions VALUES(3515-
,'SF'-
,UNISTR(-
'Vaihtolyijy'-
),UNISTR(-
'Vaihtolyijyt mekaanisiin kyniin. Joka rasia sis\00e4lt\00e4\00e4 25 lyi'||-
'jy\00e4 ja vaihtopyyhekumin. Kolme eri kokoa: 0,5 mm (ohut) - 0,7 mm (kes'||-
'kipaksu) - 0,9 mm (paksu).'-
));
INSERT INTO product_descriptions VALUES(2986-
,'SF'-
,UNISTR(-
'K\00e4sikirja - Vision OS/2x +'-
),UNISTR(-
'K\00e4sikirjat Vision-k\00e4ytt\00f6j\00e4rjestelm\00e4n versiosta 2.'||-
'x ja Vision Office Suite -toimistopaketista.'-
));
INSERT INTO product_descriptions VALUES(3163-
,'SF'-
,UNISTR(-
'K\00e4sikirja - Vision Net6.3/US'-
),UNISTR(-
'Vision Networking V6.3 -k\00e4ytt\00f6opas. Ohjelman US-versio, jossa on'||-
' tehokkaampi salaus.'-
));
INSERT INTO product_descriptions VALUES(3165-
,'SF'-
,UNISTR(-
'K\00e4sikirja - Vision Tools2.0'-
),UNISTR(-
'Vision Business Tools Suite V2.0 -k\00e4ytt\00f6opas. Sis\00e4lt\00e4'||-
'\00e4 asennus-, konfigurointi- ja k\00e4ytt\00e4j\00e4n oppaan.'-
));
INSERT INTO product_descriptions VALUES(3167-
,'SF'-
,UNISTR(-
'K\00e4sikirja - Vision OS/2.x'-
),UNISTR(-
'Vision-k\00e4ytt\00f6j\00e4rjestelmien V2.0/2.1/2/3 -k\00e4ytt\00f6op'||-
'as. T\00e4ydelliset asennus-, konfigurointi-, hallinta- ja asetustiedot V'||-
'ision-j\00e4rjestelm\00e4nhallintaan. Huom.: T\00e4m\00e4 k\00e4sikir'||-
'ja korvaa yksitt\00e4iset Version 2.0- ja 2.1 -k\00e4sikirjat.'-
));
INSERT INTO product_descriptions VALUES(3216-
,'SF'-
,UNISTR(-
'K\00e4sikirja - Vision Net6.3'-
),UNISTR(-
'Vision Networking V6.3 -k\00e4ytt\00f6opas. Ohjelman muille kuin amerikk'||-
'alaisille versioille, joissa on perustason salaus.'-
));
INSERT INTO product_descriptions VALUES(3220-
,'SF'-
,UNISTR(-
'K\00e4sikirja - Vision OS/1.2'-
),UNISTR(-
'Vision-k\00e4ytt\00f6j\00e4rjestelm\00e4n V1.2 -k\00e4ytt\00f6opas. '||-
'T\00e4ydelliset asennus-, konfigurointi-, hallinta- ja asetustiedot Visio'||-
'n-j\00e4rjestelm\00e4nhallintaan.'-
));
INSERT INTO product_descriptions VALUES(1729-
,'SF'-
,UNISTR(-
'Kemikaalit - RCP'-
),UNISTR(-
'Puhdistuskemikaalit - 3500 telanpuhdistustyyny\00e4.'-
));
INSERT INTO product_descriptions VALUES(1910-
,'SF'-
,UNISTR(-
'Lasikuitualusta - H'-
),UNISTR(-
'Eritt\00e4in tukeva lasikuitualusta, paksuus 25,4 mm.'-
));
INSERT INTO product_descriptions VALUES(1912-
,'SF'-
,UNISTR(-
'RT-alusta - 3 mm'-
),UNISTR(-
'Alusta ruostumatonta ter\00e4st\00e4 - 3 mm. Voidaan esiporata standardi'||-
'nmukaisia virtal\00e4hteit\00e4, emolevyn pidikkeit\00e4 ja kiintolevyj'||-
'\00e4 varten. Merkitse valmiin levyn mallinumero, sijoituspaikka ja koko '||-
'asianmukaiseen pohjaan, kun tilaat porattua levy\00e4.'-
));
INSERT INTO product_descriptions VALUES(1940-
,'SF'-
,UNISTR(-
'Maadoitusranneke/nipistin'-
),UNISTR(-
'Elektrostaattinen hauenleukanipistimell\00e4 varustettu maadoitusranneke '||-
'kiinnitett\00e4v\00e4ksi tietokoneen runkoon tai muuhun maadoituspistees'||-
'een.'-
));
INSERT INTO product_descriptions VALUES(2030-
,'SF'-
,UNISTR(-
'Lateksik\00e4sineet'-
),UNISTR(-
'Lateksik\00e4sineet kokoonpanijoille, kemikaalien k\00e4sittelij\00f6il'||-
'le ja asettajille. Vahva materiaali, oranssi v\00e4ri, kuvioitu tarttumap'||-
'inta sormissa. Vedenpit\00e4v\00e4t ja s\00e4hk\00f6iskun kest\00e4v'||-
'\00e4t (220 volttiin/2 ampeeriin, 110 volttiin/5 ampeeriin). Haponkest'||-
'\00e4v\00e4t enint\00e4\00e4n 5 minuutin altistuksessa.'-
));
INSERT INTO product_descriptions VALUES(2326-
,'SF'-
,UNISTR(-
'Muovialusta - Y'-
),UNISTR(-
'Keltainen muovialusta, normaali laatu.'-
));
INSERT INTO product_descriptions VALUES(2330-
,'SF'-
,UNISTR(-
'Muovialusta - R'-
),UNISTR(-
'Punainen muovialusta, normaali laatu.'-
));
INSERT INTO product_descriptions VALUES(2334-
,'SF'-
,UNISTR(-
'Hartsi'-
),UNISTR(-
'Synteettinen hartsi yleisk\00e4ytt\00f6\00f6n.'-
));
INSERT INTO product_descriptions VALUES(2340-
,'SF'-
,UNISTR(-
'Kemikaalit - SW'-
),UNISTR(-
'Puhdistuskemikaalit - 3500 antistaattista pyyhett\00e4.'-
));
INSERT INTO product_descriptions VALUES(2365-
,'SF'-
,UNISTR(-
'Kemikaalit - TCS'-
),UNISTR(-
'Puhdistuskemikaali - 2500 kuljettimen puhdistusliinaa.'-
));
INSERT INTO product_descriptions VALUES(2594-
,'SF'-
,UNISTR(-
'Lasikuitualusta - L'-
),UNISTR(-
'Lasikuitualusta, kevyt, sis\00e4iseen l\00e4mp\00f6suojaukseen, paksuus'||-
' 6,4 mm.'-
));
INSERT INTO product_descriptions VALUES(2596-
,'SF'-
,UNISTR(-
'SS Stock - 1mm'-
),UNISTR(-
'Stainless steel stock - 3mm. Voidaan esiporata vakiomallisia emolevy- ja a'||-
'kkupidikkeit\00e4 varten. Merkitse valmiin levyn mallinumero, sijoituspai'||-
'kka ja koko asianmukaiseen pohjaan, kun tilaat porattua levy\00e4.'-
));
INSERT INTO product_descriptions VALUES(2631-
,'SF'-
,UNISTR(-
'Maadoitusranneke/QR-pikairrotus'-
),UNISTR(-
'Elektrostaattinen maadoitusranneke: 2-osainen hihna, jossa pikairrotusliit'||-
'in. Yksi osa pysyy jatkuvasti kiinni ruuvilla tietokoneen rungossa, ja toi'||-
'nen osa on kiinnitetty rannekkeeseen. Kestop\00e4it\00e4 saatavana lis'||-
'\00e4varusteena.'-
));
INSERT INTO product_descriptions VALUES(2721-
,'SF'-
,UNISTR(-
'PC-kassi - L/S'-
),UNISTR(-
'Tietokonelaukku mustaa nahkaa. Tilaa yhdelle kannettavalle tietokoneelle s'||-
'ek\00e4 taskut k\00e4sikirjoille, lis\00e4varusteille ja papereille. S'||-
'\00e4\00e4dett\00e4v\00e4t turvahihnat ja irrotettava tasku virtal'||-
'\00e4hteelle ja johdoille.'-
));
INSERT INTO product_descriptions VALUES(2722-
,'SF'-
,UNISTR(-
'PC-kassi - L/D'-
),UNISTR(-
'Tietokonelaukku mustaa nahkaa. Tilaa kahdelle kannettavalle tietokoneelle '||-
'sek\00e4 taskut k\00e4sikirjoille, lis\00e4varusteille ja papereille. S'||-
'\00e4\00e4dett\00e4v\00e4t turvahihnat ja irrotettava tasku virtal'||-
'\00e4hteille ja johdoille. Mukava kaksinkertainen olkahihna.'-
));
INSERT INTO product_descriptions VALUES(2725-
,'SF'-
,UNISTR(-
'Kone\00f6ljy'-
),UNISTR(-
'Kone\00f6ljy CD-ROM-asemien luukkujen ja liukumekanismien voiteluun. Itse'||-
'puhdistuva, s\00e4\00e4dett\00e4v\00e4 suutin (ohut ->puolisakea sumu)'||-
'.'-
));
INSERT INTO product_descriptions VALUES(2782-
,'SF'-
,UNISTR(-
'PC-kassi - C/S'-
),UNISTR(-
'Tietokonelaukku kangasta. Tilaa yhdelle kannettavalle tietokoneelle sek'||-
'\00e4 taskut k\00e4sikirjoille, lis\00e4varusteille ja papereille. S'||-
'\00e4\00e4dett\00e4v\00e4t turvahihnat ja irrotettava tasku virtal'||-
'\00e4hteelle ja johdoille. Ulkopuolinen tasku nepparikiinnityksell\00e4.'-
));
INSERT INTO product_descriptions VALUES(3187-
,'SF'-
,UNISTR(-
'Muovialusta - B/HD'-
),UNISTR(-
'Sininen, eritt\00e4in tiivis muovialusta.'-
));
INSERT INTO product_descriptions VALUES(3189-
,'SF'-
,UNISTR(-
'Muovialusta - G'-
),UNISTR(-
'Vihre\00e4, normaalitiivis muovialusta.'-
));
INSERT INTO product_descriptions VALUES(3191-
,'SF'-
,UNISTR(-
'Muovialusta - O'-
),UNISTR(-
'Oranssi, normaalitiivis muovialusta.'-
));
INSERT INTO product_descriptions VALUES(3193-
,'SF'-
,UNISTR(-
'Muovialusta - W/HD'-
),UNISTR(-
'Valkoinen, eritt\00e4in tiivis muovialusta.'-
));
commit;
set define on
