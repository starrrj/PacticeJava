PROMPT Creating tables, constraints and views for Customer Orders

@@co_tables.sql

@@co_views.sql

@@co_constraints.sql

@@co_comments.sql